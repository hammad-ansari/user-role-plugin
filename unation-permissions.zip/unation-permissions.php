<?php
/**
 * UNATION Permissions
 *
 * Plugin Name: UNATION Permissions
 * Plugin URI:  https://wordpress.org/plugins/unation-permissions/
 * Description: Allow users to manage permissions.
 * Version:     0.0.1
 * Author:      Hammad Ansari
 * Author URI:  https://hammadansari.com/
 * License:     GPLv2 or later
 * License URI: http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 * Text Domain: unation-permissions
 * Domain Path: /languages
 * Requires at least: 4.9
 * Tested up to: 5.8
 * Requires PHP: 5.2.4
 *
 * This program is free software; you can redistribute it and/or modify it under the terms of the GNU
 * General Public License version 2, as published by the Free Software Foundation. You may NOT assume
 * that you can use any other version of the GPL.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 */


if (!defined('ABSPATH')) {
    die('Invalid request.');
}

define('UN_PERMISSIONS_URL', plugins_url('/', __FILE__)); // Define Plugin URL
define('UN_PERMISSIONS_PATH', plugin_dir_path(__FILE__));  // Define Plugin Directory Path


add_action( 'init', 'un_permissions_include_user_role_file' );
if( !function_exists('un_permissions_include_user_role_file') ) {
    function un_permissions_include_user_role_file() {

        $current_user = wp_get_current_user();
    
        // Check if user is an admin and return early if they are
        if ( in_array( 'administrator', (array) $current_user->roles ) ) {
            return;
        }

        $user_can_signedin = current_user_can( 'signedin_user' );
        $user_can_verified = current_user_can( 'verified_user' );
        $user_can_event = current_user_can( 'event_creator' );
        $user_can_premium = current_user_can( 'premium_business_user' );
        $user_can_city = current_user_can( 'writer' );
        $user_can_unation = current_user_can( 'unation_team_member' );
        $user_can_leadership = current_user_can( 'leadership' );
        $user_can_team = current_user_can( 'team_plus' );
        $user_can_business = current_user_can( 'business_role' );
        if($user_can_signedin){
            include(plugin_dir_path(__FILE__) . 'roles/signedin_user.php');
        }
        elseif($user_can_verified){
            include(plugin_dir_path(__FILE__) . 'roles/verified_user.php');
        }
        elseif($user_can_event){
            include(plugin_dir_path(__FILE__) . 'roles/event_creator.php');
        }
        elseif($user_can_premium){
            include(plugin_dir_path(__FILE__) . 'roles/premium_business_user.php');
        }
        elseif($user_can_city){
            include(plugin_dir_path(__FILE__) . 'roles/city_partner.php');
        }
        elseif($user_can_unation){
            include(plugin_dir_path(__FILE__) . 'roles/unation_team_member.php');
        }
        elseif($user_can_leadership){
            include(plugin_dir_path(__FILE__) . 'roles/leadership.php');
        }
        elseif($user_can_team){
            include(plugin_dir_path(__FILE__) . 'roles/team_plus.php');
        }
        elseif($user_can_business){
            include(plugin_dir_path(__FILE__) . 'roles/business_role.php');
        }
    }
}


if (!function_exists("un_permissions_create_custom_user_role")) {
    function un_permissions_create_custom_user_role($role_name, $role_slug, $role_to_copy)
    {
        if (!get_role($role_slug)) {
            // Get the capabilities of the 'copy' role
            $copy_role = get_role($role_to_copy);
            $capabilities = $copy_role->capabilities;

            // Add the new role with the same capabilities as the 'copy' role
            add_role($role_slug, $role_name, $capabilities);
        }
    }
}

if (!function_exists("un_permissions_create_user_roles")) {
    function un_permissions_create_user_roles()
    {

        un_permissions_create_custom_user_role("SignedIn User", "signedin_user", "event_creator");
        un_permissions_create_custom_user_role("Verified User", "verified_user", "event_creator");
        un_permissions_create_custom_user_role("Business User", "business_role", "event_creator");
        un_permissions_create_custom_user_role("Premium Business User", "premium_business_user", "event_creator");
        un_permissions_create_custom_user_role("PPMP", "ppmp", "unation_team_member");

        un_permissions_create_custom_user_role("Product Tester", "product_tester", "unation_email_marketer");
        
    }
}

add_action("admin_init", "un_permissions_create_user_roles");

add_action('user_register', 'add_user_approval_meta', 10, 1);
function add_user_approval_meta($user_id)
{
    update_user_meta($user_id, 'is_user_approved', false);
}


add_action('show_user_profile', 'display_user_approval_status', 10, 1);
add_action('edit_user_profile', 'display_user_approval_status', 10, 1);
function display_user_approval_status($user)
{

    if (current_user_can('manage_options')) {
        $is_approved = get_user_meta($user->ID, 'is_user_approved', true);
?>
        <h3><?php _e('User Approval Status'); ?></h3>
        <table class="form-table">
            <tr>
                <th><label for="is_user_approved"><?php _e('Is User Approved?'); ?></label></th>
                <td>
                    <input type="checkbox" name="is_user_approved" id="is_user_approved" <?php checked($is_approved, true); ?>>
                </td>
            </tr>
        </table>

<?php

    }
}



// Add custom user role when user is approved
// add_action( 'personal_options_update', 'update_user_approval_status' );
add_action('personal_options_update', 'update_user_approval_status');
add_action('edit_user_profile_update', 'update_user_approval_status');

function update_user_approval_status($user_id)
{

    if (current_user_can('manage_options')) {

        $is_approved = isset($_POST['is_user_approved']) ? true : false;
        update_user_meta($user_id, 'is_user_approved', $is_approved);


        if ($is_approved) {

            $user = new WP_User($user_id);
            $user->set_role('verified_user');
        }
    }
}

function add_custom_capability_to_post_type_args($args, $post_type)
{

    if ('text_message' === $post_type) {
        $args['capability_type'] = array('post', 'text_message');
        $args['map_meta_cap'] = true;
    }

    if ('marketing_email' === $post_type) {
        $args['capability_type'] = array('post', 'marketing_email');
        $args['map_meta_cap'] = true;
    }

    if ('unation-deal' === $post_type) {
        $args['capability_type'] = array('post', 'unation-deal');
        $args['map_meta_cap'] = true;
    }

    if ('unation-business' === $post_type) {
        $args['capability_type'] = array('post', 'unation-business');
        $args['map_meta_cap'] = true;
    }

    /*if ('shop_coupon' === $post_type) {
        $args['capability_type'] = array('post', 'shop_coupon');
        $args['map_meta_cap'] = true;
    }*/

    return $args;
}
add_filter('register_post_type_args', 'add_custom_capability_to_post_type_args', 90, 2);


function add_custom_role()
{
    $role_name = 'business_role'; // Replace with your desired role name
    $display_name = 'Business'; // Replace with the display name for the role
    $capabilities = array(
        'read' => true,
        'edit_posts' => true,
        'delete_posts' => false,
        'manage_options' => true,
        'edit_pages' => true,
        'level_10' => true,
        'level_9' => true,
        'level_8' => true,
        'level_7' => true,
        'level_6' => true,
        'level_5' => true,
        'level_4' => true,
        'level_3' => true,
        'level_2' => true,
        'level_1' => true,
        'level_0' => true,
    );
    if (!get_role($role_name)) {
        add_role($role_name, $display_name, $capabilities);
    }

    un_add_user_role('administrator', 'unation-business', true);
    un_add_user_role('administrator', 'marketing_email', true);
    un_add_user_role('leadership', 'unation-business', true);
}
add_action('init', 'add_custom_role');

if (!function_exists('un_add_user_role')) {
    function un_add_user_role($user_role, $post_type, $others)
    {

        $role = get_role($user_role);
        $role->add_cap('edit_' . $post_type);
        $role->add_cap('create_' . $post_type);
        $role->add_cap('publish_' . $post_type);
        $role->add_cap('edit_published_' . $post_type);
        $role->add_cap('edit_private_' . $post_type);
        $role->add_cap('delete_' . $post_type);
        $role->add_cap('delete_published_' . $post_type);
        $role->add_cap('delete_private_' . $post_type);
        $role->add_cap('read_private_' . $post_type);

        if ($others == true) {

            $role->add_cap('edit_others_' . $post_type);
            $role->add_cap('delete_others_' . $post_type);
        }
    }
}

if (!function_exists('un_filter_posts_by_user_role')) {
    function un_filter_posts_by_user_role($where, $wp_query)
    {
        global $wpdb;

        // Check if the current user is logged in
        if (is_user_logged_in() && is_admin()) {
            if (
                current_user_can('signedin_user') ||
                current_user_can('verified_user') ||
                current_user_can('business_role') ||
                current_user_can('premium_business_user') ||
                current_user_can('writer')
            ) {

                $current_user = wp_get_current_user();
                $user_id = $current_user->ID;

                // Filter the posts based on the user ID
                $where .= " AND $wpdb->posts.post_author = $user_id ";
            }
        }

        return $where;
    }
}

// Add the filter to the 'posts_where' hook
add_filter('posts_where', 'un_filter_posts_by_user_role', 10, 2);

if (!function_exists("un_roles_modify_all_counts")) {
    function un_roles_modify_all_counts($views)
    {
        $user = wp_get_current_user();
        $allowed_roles = array('verified_user','signedin_user','premium_business_user','business_role','writer'); // Add roles that are allowed to see the post type counts
        $post_type = isset($_REQUEST['post_type']) ? $_REQUEST['post_type'] : ''; // Get the post type from the request
        if (in_array($post_type, get_post_types()) && array_intersect($allowed_roles, $user->roles)) { // Check if the post type is valid and the user has the allowed roles
            $user_ID = get_current_user_id();
            global $wpdb;
            $counts = array();
            // Get counts for each post status
            $counts['all'] = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM $wpdb->posts WHERE post_type = %s AND post_author = %d",
                $post_type,
                $user_ID
            ));
            $counts['publish'] = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM $wpdb->posts WHERE post_type = %s AND post_author = %d AND post_status = 'publish'",
                $post_type,
                $user_ID
            ));
            $counts['draft'] = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM $wpdb->posts WHERE post_type = %s AND post_author = %d AND post_status = 'draft'",
                $post_type,
                $user_ID
            ));
            $counts['trash'] = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM $wpdb->posts WHERE post_type = %s AND post_author = %d AND post_status = 'trash'",
                $post_type,
                $user_ID
            ));
            $counts['future'] = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM $wpdb->posts WHERE post_type = %s AND post_author = %d AND post_status = 'future'",
                $post_type,
                $user_ID
            ));
            $counts['pending'] = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM $wpdb->posts WHERE post_type = %s AND post_author = %d AND post_status = 'pending'",
                $post_type,
                $user_ID
            ));
            $counts['private'] = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM $wpdb->posts WHERE post_type = %s AND post_author = %d AND post_status = 'private'",
                $post_type,
                $user_ID
            ));

            // Update the view counts
            foreach ($counts as $status => $count) {
                if (isset($views[$status])) {
                    $views[$status] = preg_replace('/\(\d+(?:,\d+)*\)/', '(' . $count . ')', $views[$status]);
                }
            }
        }
        return $views;
    }
}

if (!function_exists("un_roles_add_post_type_filter")) {
    function un_roles_add_post_type_filter()
    {
        $screen = get_current_screen();
        $post_type = $screen->post_type;
        $filter_hook = "views_edit-{$post_type}";
        add_filter($filter_hook, 'un_roles_modify_all_counts');
    }
}
add_action('admin_head', 'un_roles_add_post_type_filter');

// Add the Metro Access field to user profile
if (!function_exists('un_roles_add_metro_access_field')) {
    function un_roles_add_metro_access_field($user)
    {

        // fetch locations from Algolia
        if (!class_exists('Algolia\AlgoliaSearch\SearchClient')) return;
        $client = Algolia\AlgoliaSearch\SearchClient::create(
            'GEFWY7M6R0',
            '609adb31bcdc4e211ba577caaf9a6abf'
        );
        // Global index for all content types
        $locationObj = $client->initIndex('locations');

        $results = $locationObj->search('', [
            'facetFilters' => [
                "Type:Metro"
            ]
        ]);
        $hits = $results['hits'];

        // fetch curated cities from DB
        global $wpdb;
        $curated_cities = $wpdb->get_results( "SELECT * FROM `wp_curated_cities`" );

        $metros = [];

        foreach( $hits as $hit ) {
            foreach( $curated_cities as $city ) {

                $city_name = $city->city_name;

                if( $city_name == 'Tampa Bay' ) $city_name = 'Tampa';

                if( strpos($hit['Label'], $city_name) !== false && strpos($hit['objectID'], $city_name) !== false ) {
                    $metros[] = (object) ['label' => $city_name, 'value' => $hit['objectID']];
                    break;
                }
            }
        }

        // get the current value of the metro access option
        $metro_access = get_user_meta($user->ID, 'metro_access', true);

        // if the metro access option is not set, set it to 'all_metros'
        if (!$metro_access) {
            $metro_access = 'all_metros';
        }
?>
        <h3>Metro Access</h3>
        <table class="form-table">
            <tr>
                <th><label for="metro_access">Metro Access</label></th>
                <td>
                    <select name="metro_access" id="metro_access">
                        <option value="all_metros" <?php selected($metro_access, 'all_metros'); ?>>All Metros</option>

                        <?php foreach($metros as $metro) { ?>
                        <option value="<?php echo $metro->value; ?>" <?php selected($metro_access, $metro->value); ?>><?php echo $metro->label; ?></option>
                        <?php } ?>

                    </select>
                </td>
            </tr>
        </table>
<?php
    }
}

add_action('edit_user_profile', 'un_roles_add_metro_access_field');
add_action('show_user_profile', 'un_roles_add_metro_access_field');

// Save the Metro Access option when the user profile is updated
if (!function_exists('un_roles_save_metro_access')) {
    function un_roles_save_metro_access($user_id)
    {
        // save the value of the metro access option
        if (isset($_POST['metro_access'])) {
            update_user_meta($user_id, 'metro_access', sanitize_text_field($_POST['metro_access']));
        }
    }
}

add_action('personal_options_update', 'un_roles_save_metro_access');
add_action('edit_user_profile_update', 'un_roles_save_metro_access');


// Ad Hoc Permissions
add_action( 'show_user_profile', 'display_city_partner_ad_hoc_permissions', 10, 1 );
add_action( 'edit_user_profile', 'display_city_partner_ad_hoc_permissions', 10, 1 );
function display_city_partner_ad_hoc_permissions( $user ) {

	if ( current_user_can( 'manage_options' ) ) {

		$city_partnr_email_adhoc = get_user_meta( $user->ID, 'city_partnr_email_adhoc', true );
		$city_partnr_text_messages = get_user_meta( $user->ID, 'city_partnr_text_messages', true );
		$city_partnr_media_library = get_user_meta( $user->ID, 'city_partnr_media_library', true );
		$city_partnr_markeeting_blog = get_user_meta( $user->ID, 'city_partnr_markeeting_blog', true );
		$city_partnr_press_posts = get_user_meta( $user->ID, 'city_partnr_press_posts', true );
		$city_partnr_all_guides = get_user_meta( $user->ID, 'city_partnr_all_guides', true );
		$city_partnr_publish_pages = get_user_meta( $user->ID, 'city_partnr_publish_pages', true );
		$city_partnr_hand_raiser = get_user_meta( $user->ID, 'city_partnr_hand_raiser', true );
		$city_partnr_staff_pick = get_user_meta( $user->ID, 'city_partnr_staff_pick', true );
		$city_partnr_pittsburgh_metro = get_user_meta( $user->ID, 'city_partnr_pittsburgh_metro', true );
		?>

		<h3><?php _e( 'City Partner Ad-Hoc Permissions' ); ?></h3>
		<table class="form-table">
			<tr>
				<th><label for="city_partnr_email_adhoc"><?php _e( 'Marketing Email' ); ?></label></th>
				<td>
					<input type="checkbox" name="city_partnr_email_adhoc" id="city_partnr_email_adhoc" <?php checked( $city_partnr_email_adhoc, true ); ?>>
				</td>
			</tr>
			<tr>
				<th><label for="city_partnr_text_messages"><?php _e( 'Text Messages' ); ?></label></th>
				<td>
					<input type="checkbox" name="city_partnr_text_messages" id="city_partnr_text_messages" <?php checked( $city_partnr_text_messages, true ); ?>>
				</td>
			</tr>
			<tr>
				<th><label for="city_partnr_media_library"><?php _e( 'Media Library' ); ?></label></th>
				<td>
					<input type="checkbox" name="city_partnr_media_library" id="city_partnr_media_library" <?php checked( $city_partnr_media_library, true ); ?>>
				</td>
			</tr>

			<tr>
				<th><label for="city_partnr_markeeting_blog"><?php _e( 'Marketing Blog posts' ); ?></label></th>
				<td>
					<input type="checkbox" name="city_partnr_markeeting_blog" id="city_partnr_markeeting_blog" <?php checked( $city_partnr_markeeting_blog, true ); ?>>
				</td>
			</tr>

			<tr>
				<th><label for="city_partnr_press_posts"><?php _e( 'Press posts' ); ?></label></th>
				<td>
					<input type="checkbox" name="city_partnr_press_posts" id="city_partnr_press_posts" <?php checked( $city_partnr_press_posts, true ); ?>>
				</td>
			</tr>

			<tr>
				<th><label for="city_partnr_all_guides"><?php _e( 'Manage all Guides' ); ?></label></th>
				<td>
					<input type="checkbox" name="city_partnr_all_guides" id="city_partnr_all_guides" <?php checked( $city_partnr_all_guides, true ); ?>>
				</td>
			</tr>

			<tr>
				<th><label for="city_partnr_publish_pages"><?php _e( 'Pages' ); ?></label></th>
				<td>
					<input type="checkbox" name="city_partnr_publish_pages" id="city_partnr_publish_pages" <?php checked( $city_partnr_publish_pages, true ); ?>>
				</td>
			</tr>

			

			<tr>
				<th><label for="city_partnr_personal_pages"><?php _e( 'Manage Personal Pages' ); ?></label></th>
				<td>
					<input type="checkbox" name="city_partnr_personal_pages" id="city_partnr_personal_pages" <?php checked( $city_partnr_personal_pages, true ); ?>>
				</td>
			</tr>

			<tr>
				<th><label for="city_partnr_hand_raiser"><?php _e( 'Hand Raiser Insights' ); ?></label></th>
				<td>
					<input type="checkbox" name="city_partnr_hand_raiser" id="city_partnr_hand_raiser" <?php checked( $city_partnr_hand_raiser, true ); ?>>
				</td>
			</tr>

			<tr>
				<th><label for="city_partnr_staff_pick"><?php _e( 'Staff Pick and Feature' ); ?></label></th>
				<td>
					<input type="checkbox" name="city_partnr_staff_pick" id="city_partnr_staff_pick" <?php checked( $city_partnr_staff_pick, true ); ?>>
				</td>
			</tr>

			<!-- <tr>
				<th><label for="city_partnr_all_metro"><?php _e( 'All metro' ); ?></label></th>
				<td>
					<input type="checkbox" name="city_partnr_all_metro" id="city_partnr_all_metro" <?php checked( $city_partnr_all_metro, true ); ?>>
				</td>
			</tr>

			<tr>
				<th><label for="city_partnr_pittsburgh_metro"><?php _e( 'Pittsburgh metro' ); ?></label></th>
				<td>
					<input type="checkbox" name="city_partnr_pittsburgh_metro" id="city_partnr_pittsburgh_metro" <?php checked( $city_partnr_pittsburgh_metro, true ); ?>>
				</td>
			</tr> -->

		</table>
		<?php

	}
}



// Add custom user role when user is approved
// add_action( 'personal_options_update', 'city_partner_ad_hoc_permissions' );
add_action( 'personal_options_update', 'city_partner_ad_hoc_permissions' );
add_action( 'edit_user_profile_update', 'city_partner_ad_hoc_permissions' );

function city_partner_ad_hoc_permissions( $user_id ) {

	if ( current_user_can( 'manage_options' ) ) {


		$city_partner_email_ad_hoc = isset( $_POST['city_partnr_email_adhoc'] ) ? true : false;
		update_user_meta( $user_id, 'city_partnr_email_adhoc', $city_partner_email_ad_hoc );

		$city_partner_message_ad_hoc = isset( $_POST['city_partnr_text_messages'] ) ? true : false;
		update_user_meta( $user_id, 'city_partnr_text_messages', $city_partner_message_ad_hoc );

		$city_partner_media_ad_hoc = isset( $_POST['city_partnr_media_library'] ) ? true : false;
		update_user_meta( $user_id, 'city_partnr_media_library', $city_partner_media_ad_hoc );

		$city_partner_markeeting_blog = isset( $_POST['city_partnr_markeeting_blog'] ) ? true : false;
		update_user_meta( $user_id, 'city_partnr_markeeting_blog', $city_partner_markeeting_blog );

		$city_partner_press_posts = isset( $_POST['city_partnr_press_posts'] ) ? true : false;
		update_user_meta( $user_id, 'city_partnr_press_posts', $city_partner_press_posts );

		$city_partner_all_guides = isset( $_POST['city_partnr_all_guides'] ) ? true : false;
		update_user_meta( $user_id, 'city_partnr_all_guides', $city_partner_all_guides );

		$city_partner_publish_pages = isset( $_POST['city_partnr_publish_pages'] ) ? true : false;
		update_user_meta( $user_id, 'city_partnr_publish_pages', $city_partner_publish_pages );

		$city_partner_hand_raiser = isset( $_POST['city_partnr_hand_raiser'] ) ? true : false;
		update_user_meta( $user_id, 'city_partnr_hand_raiser', $city_partner_hand_raiser );

		$city_partner_staff_pick = isset( $_POST['city_partnr_staff_pick'] ) ? true : false;
		update_user_meta( $user_id, 'city_partnr_staff_pick', $city_partner_staff_pick );

		$city_partner_personal_pages = isset( $_POST['city_partnr_personal_pages'] ) ? true : false;
		update_user_meta( $user_id, 'city_partnr_personal_pages', $city_partner_personal_pages );

		$city_partner_pittsburgh_metro = isset( $_POST['city_partnr_pittsburgh_metro'] ) ? true : false;
		update_user_meta( $user_id, 'city_partnr_pittsburgh_metro', $city_partner_pittsburgh_metro );

		$city_partner_all_metro = isset( $_POST['city_partnr_all_metro'] ) ? true : false;
		update_user_meta( $user_id, 'city_partnr_all_metro', $city_partner_all_metro );

	}

}

if (!function_exists("un_verify_signedinuser")) {
	function un_verify_signedinuser()
	{

		if (isset($_GET['verifyUser'])) {

			$user_id = $_GET['user_id'];
			$user = get_user_by('ID', $user_id);
			$key = $_GET['key'];
			$verification_key = base64_encode($user_id . '_' . $user->user_login);

			if ($key == $verification_key) {

				$user->set_role('verified_user');
                update_user_meta($user_id, '_user_required_captcha', 0);
				wp_update_user($user);
			}

			header("Location: https://qa.unation.com/wp-admin/admin.php?page=my_dashboard");
			die();
		}
	}
}
add_action('init', 'un_verify_signedinuser');