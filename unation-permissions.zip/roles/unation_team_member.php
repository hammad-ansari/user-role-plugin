<?php

if (!function_exists("unation_team_member_capabilities")) {
	function unation_team_member_capabilities()
	{

		$user = wp_get_current_user();

		// if (current_user_can('verified_user')) {


			$to_role = get_role('unation_team_member');

			un_add_user_role('unation_team_member', 'unation-deal', true);

			$to_role_cap = $to_role->capabilities;

			$to_role->add_cap( 'edit_tribe_events' );
			$to_role->add_cap( 'edit_others_tribe_events' );
			$to_role->add_cap( 'publish_tribe_events' );
			$to_role->add_cap( 'edit_published_tribe_events' );
			$to_role->add_cap( 'edit_private_tribe_events' );
			$to_role->add_cap( 'edit_posts' );
			$to_role->add_cap( 'edit_others_posts' );
			$to_role->add_cap( 'publish_posts' );
			$to_role->add_cap( 'edit_published_posts' );
			$to_role->add_cap( 'edit_private_posts' );
			$to_role->add_cap( 'edit_pages' );
			$to_role->add_cap( 'publish_pages' );
			$to_role->add_cap( 'edit_published_pages' );
			$to_role->add_cap( 'edit_private_pages' );
			$to_role->add_cap( 'upload_files' );
			$to_role->add_cap( 'edit_products' );
			$to_role->add_cap( 'publish_products' );
			$to_role->add_cap( 'edit_published_products' );
			$to_role->add_cap( 'edit_private_products' );
			$to_role->add_cap( 'edit_shop_orders' );
			$to_role->add_cap( 'edit_others_shop_orders' );
			$to_role->add_cap( 'publish_shop_orders' );
			$to_role->add_cap( 'edit_published_shop_orders' );
			$to_role->add_cap( 'edit_private_shop_orders' );
			$to_role->add_cap( 'edit_shop_coupons' );
			$to_role->add_cap( 'publish_shop_coupons' );
			$to_role->add_cap( 'edit_published_shop_coupons' );
			$to_role->add_cap( 'edit_private_shop_coupons' );

			$to_role->add_cap( 'delete_tribe_events' );
			$to_role->add_cap( 'delete_others_tribe_events' );
			$to_role->add_cap( 'delete_published_tribe_events' );
			$to_role->add_cap( 'delete_private_tribe_events' );
			$to_role->add_cap( 'delete_posts' );
			$to_role->add_cap( 'delete_published_posts' );
			$to_role->add_cap( 'delete_shop_coupons' );
			$to_role->add_cap( 'delete_published_shop_coupons' );
			$to_role->add_cap( 'delete_private_shop_coupons' );
			$to_role->add_cap( 'delete_tribe_venues' );
			$to_role->add_cap( 'delete_tribe_organizers' );

			$to_role->add_cap( 'read_private_shop_orders' );
			$to_role->add_cap( 'read_private_tribe_events' );
			$to_role->add_cap( 'read_private_products' );
			$to_role->add_cap( 'read_private_shop_coupons' );

			$to_role->add_cap( 'assign_cities' );
			
			$to_role->add_cap( 'create_users' );
			$to_role->add_cap( 'delete_users' );
			$to_role->add_cap( 'edit_users' );
			$to_role->add_cap( 'list_users' );
			$to_role->add_cap( 'remove_users' );

			$to_role->add_cap( 'manage_options' );
			$to_role->add_cap( 'edit_dashboard' );
			$to_role->add_cap( 'read' );
			$to_role->add_cap( 'assign_shop_coupon_terms' );
			$to_role->add_cap( 'assign_shop_order_terms' );
			$to_role->add_cap( 'delete_shop_coupon_terms' );
			$to_role->add_cap( 'edit_shop_coupon_terms' );
			$to_role->add_cap( 'edit_shop_order_terms' );
			$to_role->add_cap( 'manage_shop_coupon_terms' );
			$to_role->add_cap( 'view_admin_dashboard' );


		// }
	}
}

add_action('init', 'unation_team_member_capabilities', 9999);