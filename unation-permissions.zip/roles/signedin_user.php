<?php

if (!function_exists("un_signedin_user_menu")) {
	function un_signedin_user_menu()
	{

		$user = wp_get_current_user();
		$verified_user_id = get_current_user_id();
		$all_meta_for_user = get_user_meta( $verified_user_id );
        $state= $all_meta_for_user['state'][0];
        $state_result = strtolower($state);

        $city = $all_meta_for_user['un_user_city'][0];
        $city_result = str_replace(' ', '-', strtolower($city));
        if(!empty($state)){
        	$link = get_site_url().'/'.$state_result.'/'.$city_result;
        } else {
        	$link = get_site_url().'/fl/tampa-bay/';
        }

		if (current_user_can('signedin_user')) {


			$coming_soon = get_site_url() . '/coming-soon';

			$events[] = array(
				'name' => 'Events',
				'link' => get_site_url() . '/wp-admin/edit.php?post_type=aws-event',
			);
			$events[] = array(
				'name' => 'Add New',
				'link' => get_site_url() . '/wp-admin/edit.php?post_type=aws-event&page=test-page',
			);

			/*$Settings[] = array(
				'name' => 'Account Info',
				'link' => get_site_url() . '/wp-admin/admin.php?page=my_profile',
			);

			$Settings[] = array(
				'name' => 'Purchase History',
				'link' => get_site_url() . '/wp-admin/admin.php?page=purchase_history',
			);

			$Support[] = array(
				'name' => 'Help articles',
				'link' => get_site_url() . '/wp-admin/admin.php?page=help_articles',
			);
			$Support[] = array(
				'name' => 'Feedback',
				'link' => get_site_url() . '/wp-admin/admin.php?page=feedback',
			);
			$Support[] = array(
				'name' => 'Privacy Policy',
				'link' => get_site_url() . '/privacy',
			);

			$Support[] = array(
				'name' => 'Terms of Use',
				'link' => get_site_url() . '/terms',
			);
			$Support[] = array(
				'name' => 'FAQs',
				'link' => get_site_url() . '/faqs',
			);*/




			$array_format = array(
				/*0 => array(
				
				'name'=>'Discover',
				'menu_icon' =>'<div class="wp-menu-image" aria-hidden="true"><svg width="19" height="18" viewBox="0 0 19 18" fill="none" xmlns="http://www.w3.org/2000/svg">
				<path d="M5.57931 13.0394C5.65139 13.0394 5.72321 13.0257 5.79047 12.9992L10.7596 11.0419C10.9083 10.9835 11.0259 10.8659 11.0844 10.7171L13.0416 5.74803C13.1228 5.54196 13.0789 5.30774 12.9286 5.14535C12.7785 4.98296 12.5483 4.92079 12.3366 4.98591L7.03526 6.61067C6.85223 6.66668 6.70913 6.80977 6.65286 6.9928L5.02809 12.2941C4.97476 12.4691 5.00719 12.6589 5.11598 12.8057C5.22451 12.9526 5.39655 13.0394 5.57931 13.0394L5.57931 13.0394ZM7.66549 7.6228L11.5313 6.43805L10.1041 10.0613L6.4808 11.4889L7.66549 7.6228Z" fill="url(#paint0_linear_45694_7419)"/>
				<path d="M9.04199 18C11.4289 18 13.7182 17.0519 15.4062 15.3642C17.0939 13.6762 18.0423 11.3871 18.0423 9C18.0423 6.61314 17.0942 4.32383 15.4062 2.63609C13.7184 0.948144 11.4291 0 9.04227 0C6.65541 0 4.3661 0.948076 2.67808 2.63609C0.990343 4.32383 0.0419922 6.61314 0.0419922 9C0.0446719 11.386 0.993842 13.6738 2.68103 15.361C4.36822 17.0484 6.65589 17.9973 9.04199 18V18ZM9.04199 1.1521V1.15237C11.1234 1.1521 13.1195 1.97881 14.5913 3.45052C16.063 4.92224 16.8897 6.91841 16.8897 8.99979C16.8897 11.0809 16.063 13.0771 14.5913 14.5488C13.1195 16.0205 11.1236 16.8472 9.04227 16.8475C6.96089 16.8475 4.96472 16.0205 3.49328 14.5488C2.02156 13.0771 1.19457 11.0812 1.19457 8.99979C1.19698 6.91923 2.02451 4.92443 3.49568 3.4532C4.96684 1.98203 6.96144 1.15449 9.04199 1.15209V1.1521Z" fill="url(#paint1_linear_45694_7419)"/>
				<defs>
				<linearGradient id="paint0_linear_45694_7419" x1="5.00293" y1="13.0394" x2="12.1614" y2="13.0394" gradientUnits="userSpaceOnUse">
				<stop stop-color="#F5286E"/>
				<stop offset="1" stop-color="#FC6D43"/>
				</linearGradient>
				<linearGradient id="paint1_linear_45694_7419" x1="0.0419922" y1="18" x2="15.9916" y2="18" gradientUnits="userSpaceOnUse">
				<stop stop-color="#F5286E"/>
				<stop offset="1" stop-color="#FC6D43"/>
				</linearGradient>
				</defs>
				</svg>
				</div>',
				'title' => 'Discover',
				'link'=> $link,
				'submenu' => false

			)*/

			);

			$event_menu = array(
				'name' => 'Events',
				'menu_icon' => '<div class="wp-menu-image" aria-hidden="true"><svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
				<path d="M1.04199 7.33765H19.042" stroke="url(#paint0_linear_45694_7431)" stroke-width="1.2" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
				<path d="M17.3277 2.62341H2.75628C1.8095 2.62341 1.04199 3.39092 1.04199 4.3377V17.6234C1.04199 18.5702 1.8095 19.3377 2.75628 19.3377H17.3277C18.2745 19.3377 19.042 18.5702 19.042 17.6234V4.3377C19.042 3.39092 18.2745 2.62341 17.3277 2.62341Z" stroke="url(#paint1_linear_45694_7431)" stroke-width="1.2" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
				<path d="M5.32715 4.7662V0.909058" stroke="url(#paint2_linear_45694_7431)" stroke-width="1.2" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
				<path d="M14.7568 4.7662V0.909058" stroke="url(#paint3_linear_45694_7431)" stroke-width="1.2" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
				<defs>
				<linearGradient id="paint0_linear_45694_7431" x1="1.04199" y1="8.33765" x2="16.9914" y2="8.33765" gradientUnits="userSpaceOnUse">
				<stop stop-color="#F5286E"/>
				<stop offset="1" stop-color="#FC6D43"/>
				</linearGradient>
				<linearGradient id="paint1_linear_45694_7431" x1="1.04199" y1="19.3377" x2="16.9914" y2="19.3377" gradientUnits="userSpaceOnUse">
				<stop stop-color="#F5286E"/>
				<stop offset="1" stop-color="#FC6D43"/>
				</linearGradient>
				<linearGradient id="paint2_linear_45694_7431" x1="5.32715" y1="4.7662" x2="6.21322" y2="4.7662" gradientUnits="userSpaceOnUse">
				<stop stop-color="#F5286E"/>
				<stop offset="1" stop-color="#FC6D43"/>
				</linearGradient>
				<linearGradient id="paint3_linear_45694_7431" x1="14.7568" y1="4.7662" x2="15.6429" y2="4.7662" gradientUnits="userSpaceOnUse">
				<stop stop-color="#F5286E"/>
				<stop offset="1" stop-color="#FC6D43"/>
				</linearGradient>
				</defs>
				</div>',
				'link' => 'index.php',
				'submenu' => $events
			);

			/*$support_menu = array(
				'name' => 'Support',
				'menu_icon' => '<div class="wp-menu-image" aria-hidden="true"><svg width="17" height="17" viewBox="0 0 17 17" fill="none" xmlns="http://www.w3.org/2000/svg">
				<path d="M8.33333 15.6667C12.3834 15.6667 15.6667 12.3834 15.6667 8.33333C15.6667 4.28325 12.3834 1 8.33333 1C4.28325 1 1 4.28325 1 8.33333C1 12.3834 4.28325 15.6667 8.33333 15.6667Z" stroke="#78909C" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
				<path d="M8.33333 12.6667C8.51743 12.6667 8.66667 12.5174 8.66667 12.3333C8.66667 12.1492 8.51743 12 8.33333 12C8.14924 12 8 12.1492 8 12.3333C8 12.5174 8.14924 12.6667 8.33333 12.6667Z" fill="#78909C"/>
				<path d="M8.33333 12.6667C8.51743 12.6667 8.66667 12.5174 8.66667 12.3333C8.66667 12.1492 8.51743 12 8.33333 12C8.14924 12 8 12.1492 8 12.3333C8 12.5174 8.14924 12.6667 8.33333 12.6667Z" stroke="#78909C" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
				<path d="M6.66669 4.3921C8.05269 3.7791 9.84669 3.8521 10.4597 4.8441C11.0727 5.8361 10.649 6.9891 9.59902 7.87744C8.54902 8.76577 8.33335 9.3001 8.33335 10.0001" stroke="#78909C" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
				</svg>
				</div>',
				'link' => $coming_soon,
				'submenu' => $Support
			);

			$settings_menu = array(
				'name' => 'Settings',
				'menu_icon' => '<div class="wp-menu-image" aria-hidden="true"><svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
				<path d="M9 10.7554C10.1782 10.7554 11.1333 9.80031 11.1333 8.6221C11.1333 7.4439 10.1782 6.48877 9 6.48877C7.82179 6.48877 6.86667 7.4439 6.86667 8.6221C6.86667 9.80031 7.82179 10.7554 9 10.7554Z" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
				<path d="M17 9.68874V7.5554L14.7035 7.26847C14.5594 6.66016 14.3182 6.07903 13.9893 5.5474L15.4112 3.71967L13.9024 2.21087L12.0747 3.63274C11.543 3.30383 10.9619 3.06269 10.3536 2.9186L10.0667 0.62207H7.93333L7.6464 2.9186C7.03809 3.06269 6.45696 3.30383 5.92533 3.63274L4.0976 2.21087L2.5888 3.71967L4.01067 5.5474C3.68176 6.07903 3.44062 6.66016 3.29653 7.26847L1 7.5554V9.68874L3.29653 9.97567C3.44062 10.584 3.68176 11.1651 4.01067 11.6967L2.5888 13.5245L4.0976 15.0333L5.92533 13.6114C6.45696 13.9403 7.03809 14.1814 7.6464 14.3255L7.93333 16.6221H10.0667L10.3536 14.3255C10.9619 14.1814 11.543 13.9403 12.0747 13.6114L13.9024 15.0333L15.4112 13.5245L13.9893 11.6967C14.3182 11.1651 14.5594 10.584 14.7035 9.97567L17 9.68874Z" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
				</svg>
				</div>',
				'link' => 'index.php',
				'submenu' => $Settings
			);*/

			

			$dashboard_menu = array(
					'name'=>'Dashboard',
					'menu_icon' =>'<div class="wp-menu-image" aria-hidden="true"><svg width="20" height="16" viewBox="0 0 20 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M10.041 1V3.04545" stroke="url(#paint0_linear_45682_7422)" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M19.0415 10H16.9961" stroke="url(#paint1_linear_45682_7422)" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M1.04102 10H3.08647" stroke="url(#paint2_linear_45682_7422)" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M16.4051 3.63611L14.959 5.08224" stroke="url(#paint3_linear_45682_7422)" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M3.67773 3.63623L5.12387 5.08237" stroke="url(#paint4_linear_45682_7422)" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M9.49091 8.45852L7.99609 4.27271" stroke="url(#paint5_linear_45682_7422)" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M17.5826 14.9091C18.5039 13.4969 19.041 11.8119 19.041 10C19.041 5.02955 15.0115 1 10.041 1C5.07056 1 1.04102 5.02955 1.04102 10C1.04102 11.8119 1.57815 13.4969 2.49942 14.9091H17.5826Z" stroke="url(#paint6_linear_45682_7422)" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M10.0407 11.6363C10.9444 11.6363 11.677 10.9036 11.677 9.99989C11.677 9.09615 10.9444 8.36353 10.0407 8.36353C9.13692 8.36353 8.4043 9.09615 8.4043 9.99989C8.4043 10.9036 9.13692 11.6363 10.0407 11.6363Z" stroke="url(#paint7_linear_45682_7422)" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
                    <defs>
                    <linearGradient id="paint0_linear_45682_7422" x1="10.541" y1="1" x2="10.541" y2="3.04545" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#F5286E"/>
                    <stop offset="0.645833" stop-color="#FA5950"/>
                    <stop offset="1" stop-color="#FC6D43"/>
                    </linearGradient>
                    <linearGradient id="paint1_linear_45682_7422" x1="18.0188" y1="10" x2="18.0188" y2="11" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#F5286E"/>
                    <stop offset="0.645833" stop-color="#FA5950"/>
                    <stop offset="1" stop-color="#FC6D43"/>
                    </linearGradient>
                    <linearGradient id="paint2_linear_45682_7422" x1="2.06374" y1="10" x2="2.06374" y2="11" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#F5286E"/>
                    <stop offset="0.645833" stop-color="#FA5950"/>
                    <stop offset="1" stop-color="#FC6D43"/>
                    </linearGradient>
                    <linearGradient id="paint3_linear_45682_7422" x1="15.6821" y1="3.63611" x2="15.6821" y2="5.08224" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#F5286E"/>
                    <stop offset="0.645833" stop-color="#FA5950"/>
                    <stop offset="1" stop-color="#FC6D43"/>
                    </linearGradient>
                    <linearGradient id="paint4_linear_45682_7422" x1="4.4008" y1="3.63623" x2="4.4008" y2="5.08237" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#F5286E"/>
                    <stop offset="0.645833" stop-color="#FA5950"/>
                    <stop offset="1" stop-color="#FC6D43"/>
                    </linearGradient>
                    <linearGradient id="paint5_linear_45682_7422" x1="8.7435" y1="4.27271" x2="8.7435" y2="8.45852" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#F5286E"/>
                    <stop offset="0.645833" stop-color="#FA5950"/>
                    <stop offset="1" stop-color="#FC6D43"/>
                    </linearGradient>
                    <linearGradient id="paint6_linear_45682_7422" x1="10.041" y1="1" x2="10.041" y2="14.9091" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#F5286E"/>
                    <stop offset="0.645833" stop-color="#FA5950"/>
                    <stop offset="1" stop-color="#FC6D43"/>
                    </linearGradient>
                    <linearGradient id="paint7_linear_45682_7422" x1="10.0407" y1="8.36353" x2="10.0407" y2="11.6363" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#F5286E"/>
                    <stop offset="0.645833" stop-color="#FA5950"/>
                    <stop offset="1" stop-color="#FC6D43"/>
                    </linearGradient>
                    </defs>
                    </svg>
					</div>',
					'link'=> get_site_url().'/wp-admin/admin.php?page=my_dashboard',
					'type' => 'my_dashboard',
					'submenu' => false
				);
			$array_format[] = $dashboard_menu;
			$array_format[] = $event_menu;
			
			//$array_format[] = $settings_menu;
			//$array_format[] = $support_menu;


			$absolute_url = full_url($_SERVER);
			$absolute_url = get_site_url() . $absolute_url;


			$menu_open = 'wp-menu-open';
			if( function_exists('signedin_user_search_return_index') ) $selected_key = signedin_user_search_return_index($array_format,$absolute_url);
else $selected_key = null;


?>
			<script>
				var html = `<ul id="adminmenu">`;
				<?php foreach ($array_format as $k => $menu_sub) {
					if (is_int($selected_key) && isset($selected_key) && $selected_key == $k) {
						$selected_menu = 'wp-menu-open';
					} else {
						$selected_menu = '';
					}
					if (!empty($menu_sub)) {

						$submenu = $menu_sub['submenu'];
						if (!empty($submenu)) {
							$wphas = 'wp-has-submenu';
						} else {
							$wphas = '';
						}
				?>
						html += `<li class="<?php echo $wphas; ?> wp-not-current-submenu menu-top <?php echo $selected_menu; ?>" id="toplevel_page_wp_pagely">
							<a title="<?php echo $menu_sub['name'] ?>" href="<?php echo $menu_sub['link'] ?>" class="wp-has-submenu wp-not-current-submenu menu-top toplevel_page_wp_pagely" aria-haspopup="true">`;


						<?php
						if (!empty($submenu)) { ?>
							html += `<div class="wp-menu-arrow"><div>`;
						<?php } ?>
						html += `</div></div>
								<?php echo $menu_sub['menu_icon'] ?>
								<div class="wp-menu-name"><?php echo $menu_sub['name'] ?></div>
							</a>`;
						<?php

						if (!empty($submenu)) { ?>
							html += `<ul class="wp-submenu wp-submenu-wrap" style="">`;


							<?php foreach ($submenu as $sk => $sub_val) { ?>
								html += `<li <?php echo ($sub_val['link'] == $absolute_url ? 'class="current"' : ''); ?>>`;
								<?php if (!empty($sub_val['link'])) { ?>
									html += `<a href="<?php echo $sub_val['link']; ?>" <?php echo (($sub_val['new_tab'] == true) ? 'target="_blank"' : ''); ?> <?php echo ($sub_val['link'] == $absolute_url ? 'class="current"' : ''); ?> >`;
								<?php } ?>
								html += `<?php echo $sub_val['name']; ?> `;

								<?php if (!empty($sub_val['link'])) { ?>
									html += `</a>`;
								<?php } ?>
								html += `</li>`;
							<?php } ?>
							html += `</ul>`;
						<?php } ?>
						html += `</li>`
				<?php
					}
				} ?>
				html += `<li class="wp-not-current-submenu logout" id="logout">
					<a href="<?php echo wp_logout_url(); ?>" class="wp-not-current-submenu logout">
						<div class="wp-menu-arrow">
							<div></div></div><div class="wp-menu-image dashicons-before" aria-hidden="true">
								<img src="<?php echo get_site_url(); ?>/wp-content/plugins/unation-dashboard/admin/assets/top-bar-logo.png" alt="">
							</div>
							<div class="wp-menu-name">Logout</div>
						</a></li>`;
				html += `</ul>`;

				jQuery(document).ready(function() {
					//jQuery('#adminmenuwrap>ul').remove();
					<?php
					if ($write == true) {
					?>
						// document.open();
						// document.write(html);
						// document.close();
						jQuery('div#adminmenuwrap').html(html);
					<?php
					} else {
					?>
						setTimeout(function() {
							jQuery('#adminmenuwrap>ul').html(html);
						}, 500);
					<?php } ?>
					//jQuery('ul#adminmenu > li.wp-has-submenu > a').click(function(e){
					jQuery("body").on("click", "ul#adminmenu > li.wp-has-submenu > a", function(e) {
						e.preventDefault();

						jQuery(this).toggleClass('open').next('ul.wp-submenu').slideToggle();
						var class_check = jQuery(this).parent().hasClass('wp-menu-open');

						if (class_check == true) {
							jQuery(this).parent().removeClass('wp-menu-open');
							jQuery(this).removeClass('open');
						}

					});
					//jQuery('#wpwrap #adminmenuback').click(function(e){
					// jQuery( "body" ).on( "click", '#wpwrap #adminmenuback', function() {    
					//     jQuery('#wpwrap').toggleClass('open-menu');
					// });

					jQuery("#sales_breakdown_wrapper li strong").html(function() {
						return jQuery(this)
							.html()
							.replace("Processing:", "Completed:");
					});

				});

				jQuery(window).on('load', function() {
					jQuery('body').addClass('loaded');
				});
			</script>
			
			<?php if ($absolute_url == get_site_url().'/wp-admin/admin.php?page=my_dashboard&swcfpc=1'){ ?>
		
	<?php } ?>
		<?php
		}
	}
}


add_action("admin_head", "un_signedin_user_menu");

function signedin_user_search_return_index($array_format, $search_content)
{
	$match_ind = '';

	foreach ($array_format as $k => $val) {
			$qry_string_arr = explode('&',$_SERVER['QUERY_STRING']);
			if (is_array($qry_string_arr) && count($qry_string_arr) > 0){
				foreach ($qry_string_arr as $key => $value) {
					$qry_string_value_arr = explode('=',$value);
					$qry_string_value[] = $qry_string_value_arr[1];
				}
			}
			if (is_array($qry_string_value) && count($qry_string_value) > 0){
				if (in_array($val['type'], $qry_string_value)){
					$match_ind = $k;
					return $k;
				}
			}
	}



	return $match_ind;
}



if (!function_exists("un_add_event_capabilities")) {
	function un_add_event_capabilities()
	{

		$user = wp_get_current_user();

		if (current_user_can('signedin_user')) {

			$role = get_role('signedin_user');

			$role->add_cap('edit_aws-event');
			$role->add_cap('read_aws-event');
		}
		
	}
}

add_action('init', 'un_add_event_capabilities');

function signedin_user_footer()
{

	if (current_user_can('signedin_user')) {

		?>

		<style>
			.verfiy-popup {
				display: none;
				/* hide verfiy-popup by default */
				position: fixed;
				z-index: 9999;
				left: 0;
				top: 0;
				width: 100%;
				height: 100%;
				background-color: rgba(179, 179, 179, 0.5);
				/* semi-transparent black overlay */
			}

			.verfiy-popup-content {
				width: 488px;
				position: absolute;
				top: 50%;
				left: 50%;
				transform: translate(-50%, -50%);
				background-color: #fff;
				padding: 40px;
				text-align: center;
				border-radius: 8px;
				font-family: 'Montserrat' !important;
				font-style: normal !important;
				font-weight: 600 !important;
				font-size: 16px !important;
				line-height: 30px !important;
				color: rgba(0, 0, 0, .9) !important;
			}

			.close-icon {
				position: absolute;
				top: 10px;
				right: 10px;
				font-size: 32px;
				cursor: pointer;
				font-weight: normal;
			}

			.verfiy-popup-title {
				font-family: 'Montserrat';
				font-style: normal;
				font-weight: 700;
				font-size: 20px;
				line-height: 24px;
				text-align: center;
				color: #1E1F22;
				margin-top: 0;
				margin-bottom: 10px;
			}

			.verfiy-popup-subtext {
				font-family: 'Lato';
				font-style: normal;
				font-weight: 400;
				font-size: 18px;
				line-height: 22px;
				text-align: center;
				color: #1E1F22;
				color: black;
			}

			.verfiy-popup-button {
				position: relative;
				display: inline-block;
				min-width: 150px;
				margin-top: 20px;
				padding: 10px 20px;
				font-size: 16px;
				background: linear-gradient(90deg, #F5286E 0%, #FC6D43 100%);
				box-shadow: 0px 5px 15px rgba(245, 40, 110, 0.35);
				border-radius: 8px;
				color: #fff !important;
				border-width: 0px;
				cursor: pointer;
			}

			.verfiy-popup.show {
				display: block;
				/* show verfiy-popup when "show" class is added */
			}

			.verify-loader {
				display: inline-block;
				border: 4px solid rgba(255, 255, 255, 0.3);
				border-top: 4px solid #fff;
				border-radius: 50%;
				width: 20px;
				height: 20px;
				animation: spin 1s linear infinite;
			}

			@keyframes spin {
				0% {
					transform: rotate(0deg);
				}

				100% {
					transform: rotate(360deg);
				}
			}
		</style>

		<div class="verfiy-popup">
			<div class="verfiy-popup-content">
				<span class="close-icon">&times;</span>
				<h2 class="verfiy-popup-title">Uh oh...looks like you don’t have 
access to this feature 👀</h2>
				<p class="verfiy-popup-subtext">If you want to create an event that’s 
discoverable on UNATION, please verify the email 
address associated to this account</p>
				<button class="verfiy-popup-button">Confirm email</button>
			</div>
		</div>

		<script>
			jQuery(document).ready(function($) {

				$('.close-icon').click(function() {
					$('.verfiy-popup').removeClass('show');
				});

				$(document).on('click', 'a[href*="index"]', function(e) {
				//$(document).on('click', 'a[href*="aws-event"]', function(e) {
					e.preventDefault();

					$('.verfiy-popup').addClass('show');
					$('.verfiy-popup-button').prop('disabled', false);
					$('.verfiy-popup-button').html('Confirm email');
					$('.verfiy-popup-button').css('opacity', 1);

				});

				$('.verfiy-popup-button').click(function() {
					// disable button and show loader
					$(this).prop('disabled', true);
					$(this).html('<div class="verify-loader"></div>');

					$.ajax({
						type: 'GET',
						url: '<?= admin_url('admin-ajax.php') ?>',
						data: {
							action: 'un_send_verification_email',
						},
						success: function(response) {
							console.log(response);
							if (response == 'true') {
								$('.verify-loader').remove();
								$('.verfiy-popup-button').html('Email sent');
								$('.verfiy-popup-button').css('opacity', 0.4);
							}
						}
					});

				});

			});
		</script>

<?php

	}
}
add_action('admin_head', 'signedin_user_footer');


add_action('wp_ajax_un_send_verification_email', 'un_send_verification_email');

function un_send_verification_email()
{

	$current_user = wp_get_current_user();
	$user_id = get_current_user_id();
	$curr_user_email = $current_user->user_email;
	$verification_key = base64_encode($user_id . '_' . $current_user->user_login);
	$confirm_email_url = get_site_url() . '/?verifyUser=true&user_id=' . $user_id . '&key=' . $verification_key;

	$postfield = array(
		'from' => [
			'email' => 'hi@unation.com',
			'name'  => 'UNATION'
		],
		'personalizations' => [
			0 => [
				'to' => [
					0 => [
						'email' => $curr_user_email,
					],
				],
				'dynamic_template_data' =>
				[
					'confirm_email_url' => $confirm_email_url,
				],
			],
		],
		'template_id' => 'd-a94cf984aac244d3bfa7c4b3b72bd7b7',
	);

	$json_postfield = json_encode($postfield);

	$curl = curl_init();

	curl_setopt_array($curl, array(
		CURLOPT_URL => 'https://api.sendgrid.com/v3/mail/send',
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_ENCODING => '',
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 0,
		CURLOPT_FOLLOWLOCATION => true,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => 'POST',
		CURLOPT_POSTFIELDS => $json_postfield,
		CURLOPT_HTTPHEADER => array(
			'Authorization: Bearer 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',
			'Content-Type: application/json'
		),
	));

	$response = curl_exec($curl);

	curl_close($curl);
	echo 'true';

	exit();
}
