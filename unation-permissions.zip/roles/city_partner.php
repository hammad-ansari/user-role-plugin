<?php
include_once( plugin_dir_path( __DIR__ ) . 'unation-permissions.php' );

if( !function_exists("un_city_partner_user_menu") ) {
	function un_city_partner_user_menu() {

		$user = wp_get_current_user();
		$verified_user_id = get_current_user_id();
		$all_meta_for_user = get_user_meta( $verified_user_id );
        $state= $all_meta_for_user['state'][0];
        $state_result = strtolower($state);

        $city = $all_meta_for_user['un_user_city'][0];
        $city_result = str_replace(' ', '-', strtolower($city));

        if(!empty($state)){
        	$link = get_site_url().'/'.$state_result.'/'.$city_result;
        } else {
        	$link = get_site_url().'/fl/tampa-bay/';
        }
        
		$user_email_ad_hoc_permissions = get_user_meta( $user->ID, 'city_partnr_email_adhoc', true );
		$user_message_ad_hoc_permissions = get_user_meta( $user->ID, 'city_partnr_text_messages', true );
		$media_library_ad_hoc_permissions = get_user_meta( $user->ID, 'city_partnr_media_library', true );
		$markeeting_blog_ad_hoc_permissions = get_user_meta( $user->ID, 'city_partnr_markeeting_blog', true );
		$press_posts_ad_hoc_permissions = get_user_meta( $user->ID, 'city_partnr_press_posts', true );
		$all_guides_ad_hoc_permissions = get_user_meta( $user->ID, 'city_partnr_all_guides', true );
		$publish_pages_ad_hoc_permissions = get_user_meta( $user->ID, 'city_partnr_publish_pages', true );
		$hand_raiser_ad_hoc_permissions = get_user_meta( $user->ID, 'city_partnr_hand_raiser', true );
		$staff_pick_ad_hoc_permissions = get_user_meta( $user->ID, 'city_partnr_staff_pick', true );
		$personal_pages_ad_hoc_permissions = get_user_meta( $user->ID, 'city_partnr_personal_pages', true );
		
		if (current_user_can('writer')){

			$coming_soon = get_site_url().'/coming-soon';
			
			$event[] = array(
				'name'=>'Create',
				'link'=>get_site_url().'/wp-admin/edit.php?post_type=aws-event&page=test-page',
			);
			$event[] = array(
				'name'=>'Manage',
				'link'=>get_site_url().'/wp-admin/edit.php?post_type=aws-event&page=all-events',
			);

			$create_deal[] = array(
				'name'=>'Create',
				'link'=>get_site_url().'/wp-admin/edit.php?post_type=unation-deal&page=add-new',
			);
			$create_deal[] = array(
				'name'=>'Manage',
				'link'=>get_site_url().'/wp-admin/edit.php?post_type=unation-deal',
			);

			$businesses[] = array(
				'name'=>'Create',
				'link'=>get_site_url().'/wp-admin/edit.php?post_type=unation-business&page=add-new',
			);
			$businesses[] = array(
				'name'=>'Manage',
				'link'=>get_site_url().'/wp-admin/edit.php?post_type=unation-business',
			);

			$guides[] = array(
				'name'=>'Create',
				'link'=>get_site_url().'/wp-admin/post-new.php?post_type=guide',
			);
			$guides[] = array(
				'name'=>'Manage',
				'link'=>get_site_url().'/wp-admin/edit.php?post_type=guide',
			);

			$collaborators[] = array(
				'name'=>'Event Collaborators',
				'link'=>get_site_url().'/wp-admin/users.php?page=manage-sub-users',
			);

			$text_messages[] = array(
				'name'=> 'Create',
				'link'=>get_site_url().'/wp-admin/post-new.php?post_type=text_message',
			);
			$text_messages[] = array(
				'name'=> 'Manage',
				'link'=>get_site_url().'/wp-admin/edit.php?post_type=text_message',
			);

			$emails[] = array(
				'name'=> 'Create',
				'link'=>get_site_url().'/wp-admin/post-new.php?post_type=marketing_email',
			);
			$emails[] = array(
				'name'=> 'Manage',
				'link'=>get_site_url().'/wp-admin/edit.php?post_type=marketing_email',
			);

			$marketing_blogs[] = array(
				'name'=> 'Create',
				'link'=>get_site_url().'/wp-admin/post-new.php?post_type=marketing-blogs',
			);
			$marketing_blogs[] = array(
				'name'=> 'Manage',
				'link'=>get_site_url().'/wp-admin/edit.php?post_type=marketing-blogs',
			);

			$press_posts[] = array(
				'name'=> 'Create',
				'link'=>get_site_url().'/wp-admin/post-new.php',
			);
			$press_posts[] = array(
				'name'=> 'Manage',
				'link'=>get_site_url().'/wp-admin/edit.php',
			);

			$pages[] = array(
				'name'=> 'Create',
				'link'=>get_site_url().'/wp-admin/post-new.php?post_type=page',
			);
			$pages[] = array(
				'name'=> 'Manage',
				'link'=>get_site_url().'/wp-admin/edit.php?post_type=page',
			);


			
			$array_format = array(
				/*0=> array(
				'title' => 'Discover',
				'name'=>'Discover',
				'menu_icon' =>'<div class="wp-menu-image" aria-hidden="true"><svg width="19" height="18" viewBox="0 0 19 18" fill="none" xmlns="http://www.w3.org/2000/svg">
				<path d="M5.57931 13.0394C5.65139 13.0394 5.72321 13.0257 5.79047 12.9992L10.7596 11.0419C10.9083 10.9835 11.0259 10.8659 11.0844 10.7171L13.0416 5.74803C13.1228 5.54196 13.0789 5.30774 12.9286 5.14535C12.7785 4.98296 12.5483 4.92079 12.3366 4.98591L7.03526 6.61067C6.85223 6.66668 6.70913 6.80977 6.65286 6.9928L5.02809 12.2941C4.97476 12.4691 5.00719 12.6589 5.11598 12.8057C5.22451 12.9526 5.39655 13.0394 5.57931 13.0394L5.57931 13.0394ZM7.66549 7.6228L11.5313 6.43805L10.1041 10.0613L6.4808 11.4889L7.66549 7.6228Z" fill="url(#paint0_linear_45694_7419)"/>
				<path d="M9.04199 18C11.4289 18 13.7182 17.0519 15.4062 15.3642C17.0939 13.6762 18.0423 11.3871 18.0423 9C18.0423 6.61314 17.0942 4.32383 15.4062 2.63609C13.7184 0.948144 11.4291 0 9.04227 0C6.65541 0 4.3661 0.948076 2.67808 2.63609C0.990343 4.32383 0.0419922 6.61314 0.0419922 9C0.0446719 11.386 0.993842 13.6738 2.68103 15.361C4.36822 17.0484 6.65589 17.9973 9.04199 18V18ZM9.04199 1.1521V1.15237C11.1234 1.1521 13.1195 1.97881 14.5913 3.45052C16.063 4.92224 16.8897 6.91841 16.8897 8.99979C16.8897 11.0809 16.063 13.0771 14.5913 14.5488C13.1195 16.0205 11.1236 16.8472 9.04227 16.8475C6.96089 16.8475 4.96472 16.0205 3.49328 14.5488C2.02156 13.0771 1.19457 11.0812 1.19457 8.99979C1.19698 6.91923 2.02451 4.92443 3.49568 3.4532C4.96684 1.98203 6.96144 1.15449 9.04199 1.15209V1.1521Z" fill="url(#paint1_linear_45694_7419)"/>
				<defs>
				<linearGradient id="paint0_linear_45694_7419" x1="5.00293" y1="13.0394" x2="12.1614" y2="13.0394" gradientUnits="userSpaceOnUse">
				<stop stop-color="#F5286E"/>
				<stop offset="1" stop-color="#FC6D43"/>
				</linearGradient>
				<linearGradient id="paint1_linear_45694_7419" x1="0.0419922" y1="18" x2="15.9916" y2="18" gradientUnits="userSpaceOnUse">
				<stop stop-color="#F5286E"/>
				<stop offset="1" stop-color="#FC6D43"/>
				</linearGradient>
				</defs>
				</svg>
				</div>',
				
				'link'=> $link,
				'submenu' => false

			)*/
			);

			$dashboard_menu = array(
					'name'=>'Dashboard',
					'menu_icon' =>'<div class="wp-menu-image" aria-hidden="true"><svg width="20" height="16" viewBox="0 0 20 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M10.041 1V3.04545" stroke="url(#paint0_linear_45682_7422)" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M19.0415 10H16.9961" stroke="url(#paint1_linear_45682_7422)" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M1.04102 10H3.08647" stroke="url(#paint2_linear_45682_7422)" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M16.4051 3.63611L14.959 5.08224" stroke="url(#paint3_linear_45682_7422)" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M3.67773 3.63623L5.12387 5.08237" stroke="url(#paint4_linear_45682_7422)" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M9.49091 8.45852L7.99609 4.27271" stroke="url(#paint5_linear_45682_7422)" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M17.5826 14.9091C18.5039 13.4969 19.041 11.8119 19.041 10C19.041 5.02955 15.0115 1 10.041 1C5.07056 1 1.04102 5.02955 1.04102 10C1.04102 11.8119 1.57815 13.4969 2.49942 14.9091H17.5826Z" stroke="url(#paint6_linear_45682_7422)" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M10.0407 11.6363C10.9444 11.6363 11.677 10.9036 11.677 9.99989C11.677 9.09615 10.9444 8.36353 10.0407 8.36353C9.13692 8.36353 8.4043 9.09615 8.4043 9.99989C8.4043 10.9036 9.13692 11.6363 10.0407 11.6363Z" stroke="url(#paint7_linear_45682_7422)" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
                    <defs>
                    <linearGradient id="paint0_linear_45682_7422" x1="10.541" y1="1" x2="10.541" y2="3.04545" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#F5286E"/>
                    <stop offset="0.645833" stop-color="#FA5950"/>
                    <stop offset="1" stop-color="#FC6D43"/>
                    </linearGradient>
                    <linearGradient id="paint1_linear_45682_7422" x1="18.0188" y1="10" x2="18.0188" y2="11" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#F5286E"/>
                    <stop offset="0.645833" stop-color="#FA5950"/>
                    <stop offset="1" stop-color="#FC6D43"/>
                    </linearGradient>
                    <linearGradient id="paint2_linear_45682_7422" x1="2.06374" y1="10" x2="2.06374" y2="11" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#F5286E"/>
                    <stop offset="0.645833" stop-color="#FA5950"/>
                    <stop offset="1" stop-color="#FC6D43"/>
                    </linearGradient>
                    <linearGradient id="paint3_linear_45682_7422" x1="15.6821" y1="3.63611" x2="15.6821" y2="5.08224" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#F5286E"/>
                    <stop offset="0.645833" stop-color="#FA5950"/>
                    <stop offset="1" stop-color="#FC6D43"/>
                    </linearGradient>
                    <linearGradient id="paint4_linear_45682_7422" x1="4.4008" y1="3.63623" x2="4.4008" y2="5.08237" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#F5286E"/>
                    <stop offset="0.645833" stop-color="#FA5950"/>
                    <stop offset="1" stop-color="#FC6D43"/>
                    </linearGradient>
                    <linearGradient id="paint5_linear_45682_7422" x1="8.7435" y1="4.27271" x2="8.7435" y2="8.45852" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#F5286E"/>
                    <stop offset="0.645833" stop-color="#FA5950"/>
                    <stop offset="1" stop-color="#FC6D43"/>
                    </linearGradient>
                    <linearGradient id="paint6_linear_45682_7422" x1="10.041" y1="1" x2="10.041" y2="14.9091" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#F5286E"/>
                    <stop offset="0.645833" stop-color="#FA5950"/>
                    <stop offset="1" stop-color="#FC6D43"/>
                    </linearGradient>
                    <linearGradient id="paint7_linear_45682_7422" x1="10.0407" y1="8.36353" x2="10.0407" y2="11.6363" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#F5286E"/>
                    <stop offset="0.645833" stop-color="#FA5950"/>
                    <stop offset="1" stop-color="#FC6D43"/>
                    </linearGradient>
                    </defs>
                    </svg>
					</div>',
					'link'=> get_site_url().'/wp-admin/admin.php?page=my_dashboard',
					'type' => 'my_dashboard',
					'submenu' => false
				);
				

			/*$dicover_menu = array(
				
				'name'=>'Discover',
				'menu_icon' =>'<div class="wp-menu-image" aria-hidden="true"><svg width="19" height="18" viewBox="0 0 19 18" fill="none" xmlns="http://www.w3.org/2000/svg">
				<path d="M5.57931 13.0394C5.65139 13.0394 5.72321 13.0257 5.79047 12.9992L10.7596 11.0419C10.9083 10.9835 11.0259 10.8659 11.0844 10.7171L13.0416 5.74803C13.1228 5.54196 13.0789 5.30774 12.9286 5.14535C12.7785 4.98296 12.5483 4.92079 12.3366 4.98591L7.03526 6.61067C6.85223 6.66668 6.70913 6.80977 6.65286 6.9928L5.02809 12.2941C4.97476 12.4691 5.00719 12.6589 5.11598 12.8057C5.22451 12.9526 5.39655 13.0394 5.57931 13.0394L5.57931 13.0394ZM7.66549 7.6228L11.5313 6.43805L10.1041 10.0613L6.4808 11.4889L7.66549 7.6228Z" fill="url(#paint0_linear_45694_7419)"/>
				<path d="M9.04199 18C11.4289 18 13.7182 17.0519 15.4062 15.3642C17.0939 13.6762 18.0423 11.3871 18.0423 9C18.0423 6.61314 17.0942 4.32383 15.4062 2.63609C13.7184 0.948144 11.4291 0 9.04227 0C6.65541 0 4.3661 0.948076 2.67808 2.63609C0.990343 4.32383 0.0419922 6.61314 0.0419922 9C0.0446719 11.386 0.993842 13.6738 2.68103 15.361C4.36822 17.0484 6.65589 17.9973 9.04199 18V18ZM9.04199 1.1521V1.15237C11.1234 1.1521 13.1195 1.97881 14.5913 3.45052C16.063 4.92224 16.8897 6.91841 16.8897 8.99979C16.8897 11.0809 16.063 13.0771 14.5913 14.5488C13.1195 16.0205 11.1236 16.8472 9.04227 16.8475C6.96089 16.8475 4.96472 16.0205 3.49328 14.5488C2.02156 13.0771 1.19457 11.0812 1.19457 8.99979C1.19698 6.91923 2.02451 4.92443 3.49568 3.4532C4.96684 1.98203 6.96144 1.15449 9.04199 1.15209V1.1521Z" fill="url(#paint1_linear_45694_7419)"/>
				<defs>
				<linearGradient id="paint0_linear_45694_7419" x1="5.00293" y1="13.0394" x2="12.1614" y2="13.0394" gradientUnits="userSpaceOnUse">
				<stop stop-color="#F5286E"/>
				<stop offset="1" stop-color="#FC6D43"/>
				</linearGradient>
				<linearGradient id="paint1_linear_45694_7419" x1="0.0419922" y1="18" x2="15.9916" y2="18" gradientUnits="userSpaceOnUse">
				<stop stop-color="#F5286E"/>
				<stop offset="1" stop-color="#FC6D43"/>
				</linearGradient>
				</defs>
				</svg>
				</div>',
				'title' => 'Discover',
				'link'=> get_site_url(),
				'submenu' => false

			);*/

			$event_menu = array(
				'name'=>'Events',
				'menu_icon' => '<div class="wp-menu-image" aria-hidden="true"><svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
				<path d="M1.04199 7.33765H19.042" stroke="url(#paint0_linear_45694_7431)" stroke-width="1.2" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
				<path d="M17.3277 2.62341H2.75628C1.8095 2.62341 1.04199 3.39092 1.04199 4.3377V17.6234C1.04199 18.5702 1.8095 19.3377 2.75628 19.3377H17.3277C18.2745 19.3377 19.042 18.5702 19.042 17.6234V4.3377C19.042 3.39092 18.2745 2.62341 17.3277 2.62341Z" stroke="url(#paint1_linear_45694_7431)" stroke-width="1.2" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
				<path d="M5.32715 4.7662V0.909058" stroke="url(#paint2_linear_45694_7431)" stroke-width="1.2" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
				<path d="M14.7568 4.7662V0.909058" stroke="url(#paint3_linear_45694_7431)" stroke-width="1.2" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
				<defs>
				<linearGradient id="paint0_linear_45694_7431" x1="1.04199" y1="8.33765" x2="16.9914" y2="8.33765" gradientUnits="userSpaceOnUse">
				<stop stop-color="#F5286E"/>
				<stop offset="1" stop-color="#FC6D43"/>
				</linearGradient>
				<linearGradient id="paint1_linear_45694_7431" x1="1.04199" y1="19.3377" x2="16.9914" y2="19.3377" gradientUnits="userSpaceOnUse">
				<stop stop-color="#F5286E"/>
				<stop offset="1" stop-color="#FC6D43"/>
				</linearGradient>
				<linearGradient id="paint2_linear_45694_7431" x1="5.32715" y1="4.7662" x2="6.21322" y2="4.7662" gradientUnits="userSpaceOnUse">
				<stop stop-color="#F5286E"/>
				<stop offset="1" stop-color="#FC6D43"/>
				</linearGradient>
				<linearGradient id="paint3_linear_45694_7431" x1="14.7568" y1="4.7662" x2="15.6429" y2="4.7662" gradientUnits="userSpaceOnUse">
				<stop stop-color="#F5286E"/>
				<stop offset="1" stop-color="#FC6D43"/>
				</linearGradient>
				</defs>
				</div>',
				'title' => 'Events',
				'link'=>get_site_url().'/wp-admin/edit.php?post_type=aws-event&page=all-events',
				'type' => 'aws-event',
				'submenu' => false
			);

// 			$Offers_menu = array(
// 				'name'=>'Offers',
// 				'menu_icon' => '<div class="wp-menu-image" aria-hidden="true"><svg width="12" height="19" viewBox="0 0 12 19" fill="none" xmlns="http://www.w3.org/2000/svg">
// 				<mask id="mask0_42075_59766" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="12" height="19">
// 				<rect x="1" y="1.33771" width="9.45455" height="16" fill="#D9D9D9" stroke="#78818B" stroke-width="2"/>
// 				</mask>
// 				<g mask="url(#mask0_42075_59766)">
// 				<mask id="path-2-inside-1_42075_59766" fill="white">
// 				<path d="M0.608373 17.8992L1.22531 17.9028L3.48744 17.9163L4.10438 17.92L4.10801 17.3118C4.11337 16.409 4.84697 15.6944 5.76285 15.6999C6.67878 15.7053 7.40374 16.4285 7.39836 17.3314L7.39475 17.9396L8.01169 17.9432L10.2738 17.9567L10.8908 17.9604L10.8944 17.3522L10.9909 1.1349L10.9945 0.526766L10.3776 0.523087L8.11547 0.509622L7.49852 0.505944L7.49489 1.1141C7.48952 2.01696 6.756 2.73149 5.84006 2.72604C4.92417 2.72059 4.19915 1.99734 4.20452 1.09451L4.20816 0.48636L3.5912 0.482696L1.32908 0.469215L0.712132 0.46556L0.708507 1.0737L0.611962 17.291L0.608355 17.8991L0.608373 17.8992ZM1.84949 16.6902L1.90861 6.75709L9.72325 6.80364L9.66412 16.7367L8.55876 16.7301C8.28119 15.4583 7.14078 14.4918 5.77007 14.4836C4.39942 14.4754 3.24112 15.4283 2.94842 16.6968L1.84949 16.6902ZM1.91585 5.5408L1.93877 1.6892L3.03771 1.69574C3.31529 2.96758 4.46215 3.93418 5.83282 3.94233C7.20352 3.9505 8.35535 2.99758 8.64805 1.72914L9.75342 1.73572L9.73049 5.58732L1.91585 5.5408Z"/>
// 				</mask>
// 				<path d="M0.608373 17.8992L-0.82429 19.2947L-0.237781 19.8797L0.596564 19.8847L0.608373 17.8992ZM1.22531 17.9028L1.23715 15.9173L1.23712 15.9173L1.22531 17.9028ZM3.48744 17.9163L3.4756 19.9019L3.47571 19.9019L3.48744 17.9163ZM4.10438 17.92L4.09265 19.9055L6.10679 19.9174L6.11865 17.932L4.10438 17.92ZM4.10801 17.3118L6.12228 17.3239L6.12228 17.3238L4.10801 17.3118ZM5.76285 15.6999L5.75103 17.6855L5.75106 17.6855L5.76285 15.6999ZM7.39836 17.3314L5.38409 17.3194L5.38409 17.3194L7.39836 17.3314ZM7.39475 17.9396L5.38048 17.9276L5.36868 19.9131L7.38291 19.9251L7.39475 17.9396ZM8.01169 17.9432L7.99985 19.9288L7.99987 19.9288L8.01169 17.9432ZM10.2738 17.9567L10.2857 15.9711L10.2857 15.9711L10.2738 17.9567ZM10.8908 17.9604L10.8789 19.9459L12.8932 19.9579L12.905 17.9724L10.8908 17.9604ZM10.8944 17.3522L8.88012 17.3402L8.88012 17.3403L10.8944 17.3522ZM10.9909 1.1349L8.97665 1.1229L8.97665 1.12291L10.9909 1.1349ZM10.9945 0.526766L13.0088 0.538767L13.0207 -1.44678L11.0064 -1.45879L10.9945 0.526766ZM10.3776 0.523087L10.3894 -1.46247L10.3894 -1.46247L10.3776 0.523087ZM8.11547 0.509622L8.10363 2.49518L8.10365 2.49518L8.11547 0.509622ZM7.49852 0.505944L7.51036 -1.47961L5.4961 -1.49162L5.48425 0.493926L7.49852 0.505944ZM7.49489 1.1141L5.48062 1.10209L5.48062 1.10211L7.49489 1.1141ZM5.84006 2.72604L5.85188 0.740485L5.85187 0.740485L5.84006 2.72604ZM4.20452 1.09451L2.19025 1.08247L2.19025 1.08254L4.20452 1.09451ZM4.20816 0.48636L6.22243 0.498408L6.23431 -1.48723L4.21995 -1.49919L4.20816 0.48636ZM3.5912 0.482696L3.57937 2.46825L3.57941 2.46825L3.5912 0.482696ZM1.32908 0.469215L1.34091 -1.51634L1.34084 -1.51634L1.32908 0.469215ZM0.712132 0.46556L0.723894 -1.51999L-1.29031 -1.53193L-1.30214 0.453555L0.712132 0.46556ZM0.708507 1.0737L-1.30576 1.0617L-1.30576 1.06171L0.708507 1.0737ZM0.611962 17.291L-1.40231 17.279L-1.40231 17.279L0.611962 17.291ZM0.608355 17.8991L-1.40592 17.8872L-1.41079 18.7096L-0.824308 19.2947L0.608355 17.8991ZM1.90861 6.75709L1.92044 4.77154L-0.0938411 4.75954L-0.105659 6.7451L1.90861 6.75709ZM9.72325 6.80364L11.7375 6.81563L11.7493 4.83008L9.73508 4.81808L9.72325 6.80364ZM9.66412 16.7367L9.65231 18.7223L11.6666 18.7343L11.6784 16.7487L9.66412 16.7367ZM8.55876 16.7301L6.58952 17.1474L6.92968 18.7061L8.54695 18.7157L8.55876 16.7301ZM5.77007 14.4836L5.75825 16.4691L5.77007 14.4836ZM2.94842 16.6968L2.93661 18.6823L4.55385 18.6919L4.91255 17.1375L2.94842 16.6968ZM1.84949 16.6902L-0.164781 16.6782L-0.176599 18.6638L1.83768 18.6758L1.84949 16.6902ZM1.93877 1.6892L1.9506 -0.296359L-0.0636836 -0.308358L-0.075499 1.67721L1.93877 1.6892ZM3.03771 1.69574L5.00695 1.27843L4.66678 -0.280179L3.04954 -0.289813L3.03771 1.69574ZM5.83282 3.94233L5.84466 1.95677L5.84462 1.95677L5.83282 3.94233ZM8.64805 1.72914L8.65988 -0.256417L7.04263 -0.266049L6.68392 1.28841L8.64805 1.72914ZM9.75342 1.73572L11.7677 1.74771L11.7795 -0.237838L9.76524 -0.249834L9.75342 1.73572ZM9.73049 5.58732L9.71867 7.57287L11.7329 7.58486L11.7448 5.59931L9.73049 5.58732ZM1.91585 5.5408L-0.0984201 5.52882L-0.110236 7.51437L1.90403 7.52636L1.91585 5.5408ZM0.596564 19.8847L1.2135 19.8884L1.23712 15.9173L0.620183 15.9136L0.596564 19.8847ZM1.21347 19.8884L3.4756 19.9019L3.49928 15.9308L1.23715 15.9173L1.21347 19.8884ZM3.47571 19.9019L4.09265 19.9055L4.11611 15.9344L3.49917 15.9308L3.47571 19.9019ZM6.11865 17.932L6.12228 17.3239L2.09374 17.2998L2.09011 17.9079L6.11865 17.932ZM6.12228 17.3238C6.12113 17.5176 5.94756 17.6866 5.75103 17.6855L5.77467 13.7143C3.74638 13.7023 2.10561 15.3004 2.09374 17.2999L6.12228 17.3238ZM5.75106 17.6855C5.55447 17.6843 5.38294 17.5131 5.38409 17.3194L9.41264 17.3434C9.42454 15.344 7.80308 13.7264 5.77464 13.7143L5.75106 17.6855ZM5.38409 17.3194L5.38048 17.9276L9.40902 17.9515L9.41264 17.3434L5.38409 17.3194ZM7.38291 19.9251L7.99985 19.9288L8.02353 15.9577L7.40659 15.954L7.38291 19.9251ZM7.99987 19.9288L10.262 19.9423L10.2857 15.9711L8.02351 15.9577L7.99987 19.9288ZM10.262 19.9423L10.8789 19.9459L10.9026 15.9748L10.2857 15.9711L10.262 19.9423ZM12.905 17.9724L12.9087 17.3642L8.88012 17.3403L8.8765 17.9484L12.905 17.9724ZM12.9087 17.3642L13.0052 1.1469L8.97665 1.12291L8.88012 17.3402L12.9087 17.3642ZM13.0052 1.14691L13.0088 0.538767L8.98028 0.514764L8.97665 1.1229L13.0052 1.14691ZM11.0064 -1.45879L10.3894 -1.46247L10.3658 2.50864L10.9827 2.51232L11.0064 -1.45879ZM10.3894 -1.46247L8.12729 -1.47593L8.10365 2.49518L10.3658 2.50864L10.3894 -1.46247ZM8.12731 -1.47593L7.51036 -1.47961L7.48668 2.4915L8.10363 2.49518L8.12731 -1.47593ZM5.48425 0.493926L5.48062 1.10209L9.50917 1.12612L9.51279 0.517961L5.48425 0.493926ZM5.48062 1.10211C5.48178 0.908399 5.65534 0.739315 5.85188 0.740485L5.82824 4.71159C7.85665 4.72367 9.49726 3.12552 9.50917 1.1261L5.48062 1.10211ZM5.85187 0.740485C6.04845 0.741655 6.21995 0.912751 6.2188 1.10649L2.19025 1.08254C2.17836 3.08194 3.79989 4.69952 5.82824 4.71159L5.85187 0.740485ZM6.21879 1.10656L6.22243 0.498408L2.19389 0.474312L2.19025 1.08247L6.21879 1.10656ZM4.21995 -1.49919L3.60299 -1.50286L3.57941 2.46825L4.19637 2.47191L4.21995 -1.49919ZM3.60304 -1.50286L1.34091 -1.51634L1.31725 2.45477L3.57937 2.46825L3.60304 -1.50286ZM1.34084 -1.51634L0.723894 -1.51999L0.700369 2.45111L1.31732 2.45477L1.34084 -1.51634ZM-1.30214 0.453555L-1.30576 1.0617L2.72278 1.0857L2.7264 0.477564L-1.30214 0.453555ZM-1.30576 1.06171L-1.40231 17.279L2.62623 17.303L2.72278 1.08569L-1.30576 1.06171ZM-1.40231 17.279L-1.40592 17.8872L2.62263 17.9111L2.62623 17.3029L-1.40231 17.279ZM-0.824308 19.2947L-0.82429 19.2947L2.04104 16.5036L2.04102 16.5036L-0.824308 19.2947ZM3.86376 16.7022L3.92288 6.76908L-0.105659 6.7451L-0.164781 16.6782L3.86376 16.7022ZM1.89679 8.74265L9.71142 8.78919L9.73508 4.81808L1.92044 4.77154L1.89679 8.74265ZM7.70898 6.79165L7.64984 16.7247L11.6784 16.7487L11.7375 6.81563L7.70898 6.79165ZM9.67593 14.7512L8.57057 14.7446L8.54695 18.7157L9.65231 18.7223L9.67593 14.7512ZM10.528 16.3129C10.0591 14.1641 8.13178 12.512 5.78189 12.498L5.75825 16.4691C6.14979 16.4715 6.50333 16.7525 6.58952 17.1474L10.528 16.3129ZM5.78189 12.498C3.43749 12.4841 1.48003 14.1077 0.984281 16.256L4.91255 17.1375C5.00221 16.7489 5.36135 16.4668 5.75825 16.4691L5.78189 12.498ZM2.96023 14.7112L1.8613 14.7047L1.83768 18.6758L2.93661 18.6823L2.96023 14.7112ZM3.93012 5.55279L3.95304 1.70118L-0.075499 1.67721L-0.0984201 5.52882L3.93012 5.55279ZM1.92694 3.67475L3.02588 3.6813L3.04954 -0.289813L1.9506 -0.296359L1.92694 3.67475ZM1.06846 2.11305C1.5386 4.26714 3.47658 5.91394 5.82101 5.92788L5.84462 1.95677C5.44771 1.95441 5.09198 1.66801 5.00695 1.27843L1.06846 2.11305ZM5.82098 5.92788C8.17088 5.9419 10.1177 4.31285 10.6122 2.16986L6.68392 1.28841C6.59302 1.6823 6.23615 1.95911 5.84466 1.95677L5.82098 5.92788ZM8.63623 3.71469L9.74159 3.72127L9.76524 -0.249834L8.65988 -0.256417L8.63623 3.71469ZM7.73914 1.72373L7.71621 5.57533L11.7448 5.59931L11.7677 1.74771L7.73914 1.72373ZM9.74231 3.60176L1.92767 3.55525L1.90403 7.52636L9.71867 7.57287L9.74231 3.60176Z" fill="#78818B" mask="url(#path-2-inside-1_42075_59766)"/>
// 				</g>
// 				</svg>
// 				</div>',
// 				'title' => 'Offers',
// 				'link'=>'index.php',
// 				'submenu'=>$create_deal
// 			);

// $businesses_menu = array(
// 	'name'=>'Businesses',
// 	'menu_icon' => '<div class="wp-menu-image" aria-hidden="true"><svg width="14" height="20" viewBox="0 0 14 20" fill="none" xmlns="http://www.w3.org/2000/svg">
// 	<path d="M1 3.90908L7.09511 1.33771L13.1902 3.90908V19.3373H1V3.90908Z" stroke="#828282" stroke-miterlimit="10" stroke-linecap="square"/>
// 	<path d="M4.04688 7.33771V8.19483" stroke="#828282" stroke-miterlimit="10" stroke-linecap="square"/>
// 	<path d="M7.09521 7.33771V8.19483" stroke="#828282" stroke-miterlimit="10" stroke-linecap="square"/>
// 	<path d="M10.1421 7.33771V8.19483" stroke="#828282" stroke-miterlimit="10" stroke-linecap="square"/>
// 	<path d="M4.04834 11.6228V12.4799" stroke="#828282" stroke-miterlimit="10" stroke-linecap="square"/>
// 	<path d="M7.09521 11.623V12.4801" stroke="#828282" stroke-miterlimit="10" stroke-linecap="square"/>
// 	<path d="M10.1421 11.623V12.4801" stroke="#828282" stroke-miterlimit="10" stroke-linecap="square"/>
// 	<path d="M6.07324 18.8382V15.5526H8.1208V18.8382H6.07324Z" fill="#F2F2F2" stroke="#828282"/>
// 	</svg>
// 	</div>',
// 	'title' => 'Businesses',
// 	'link'=>'index.php',
// 	'submenu' => $businesses
// );


$guides_menu = array(
	'name'=>'Guides',
	'menu_icon' => '<div class="wp-menu-image" aria-hidden="true"><svg width="18" height="20" viewBox="0 0 18 20" fill="none" xmlns="http://www.w3.org/2000/svg">
	<path d="M4.94877 16.0651V17.2923C4.94877 19.1331 2.90137 19.3376 2.90137 19.3376C2.90137 19.3376 15.0458 19.3376 15.1858 19.3376C16.3168 19.3376 17.2332 18.4221 17.2332 17.2923V16.0651H4.94877Z" stroke="#FA5950" stroke-width="1.2" stroke-miterlimit="10" stroke-linecap="square"/>
	<path d="M14.7729 13.6097V1.33765H0.850586V17.2913C0.850586 18.4212 1.767 19.3366 2.89799 19.3366H4.12643" stroke="#FA5950" stroke-width="1.2" stroke-miterlimit="10" stroke-linecap="square"/>
	<path d="M4.94629 5.42871H10.679" stroke="#FA5950" stroke-width="1.2" stroke-miterlimit="10" stroke-linecap="square"/>
	<path d="M4.94629 8.70032H10.679" stroke="#FA5950" stroke-width="1.2" stroke-miterlimit="10" stroke-linecap="square"/>
	<path d="M4.94629 11.9741H10.679" stroke="#FA5950" stroke-width="1.2" stroke-miterlimit="10" stroke-linecap="square"/>
	</svg>

	</div>',
	'title' => 'Guides',
	'link'=>get_site_url().'/wp-admin/edit.php?post_type=guide',
	'type' => 'guide',
	'submenu' => false
);

$promo_codes_menu = array(
	'name'=>'Promo Codes',
	'menu_icon' => '<div class="wp-menu-image" aria-hidden="true"><svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
	<circle cx="11.51" cy="9.21064" r="1.33848" stroke="#FA5950" stroke-width="0.8"/>
	<circle cx="5.71504" cy="9.21064" r="1.33848" stroke="#FA5950" stroke-width="0.8"/>
	<path d="M16.7256 4.81085L17.2679 4.90282L17.3151 4.62425L17.1162 4.42361L16.7256 4.81085ZM13.6185 1.67712L14.0091 1.28988L13.8177 1.09679L13.548 1.13166L13.6185 1.67712ZM8.23296 2.37351L8.16243 1.82805L7.97663 1.85207L7.84413 1.98451L8.23296 2.37351ZM1.31619 9.28735L0.927368 8.89836H0.927368L1.31619 9.28735ZM1.31253 10.9231L1.70309 10.5358H1.70309L1.31253 10.9231ZM7.40249 17.0653L7.79305 16.6781L7.40249 17.0653ZM9.05585 17.0579L8.66181 16.6741H8.66181L9.05585 17.0579ZM15.828 10.1034L16.222 10.4871L16.3416 10.3643L16.3703 10.1953L15.828 10.1034ZM9.09811 19.2237L9.09102 19.7736L9.09811 19.2237ZM17.9321 19.3375L17.925 19.8875L17.9321 19.3375ZM19.106 18.1787H19.656H19.106ZM19.106 7.84125H19.656V7.66076L19.5491 7.51536L19.106 7.84125ZM7.95406 18.0648H7.40406H7.95406ZM10.4126 5.91836C10.5045 5.62884 10.3443 5.31963 10.0548 5.22772C9.76526 5.13581 9.45605 5.296 9.36414 5.58552L10.4126 5.91836ZM6.8983 13.3529C6.80639 13.6424 6.96658 13.9516 7.2561 14.0436C7.54562 14.1355 7.85483 13.9753 7.94674 13.6858L6.8983 13.3529ZM13.2573 3.36864C13.0426 3.15385 12.6943 3.15385 12.4795 3.36864C12.2647 3.58343 12.2647 3.93167 12.4795 4.14646L13.2573 3.36864ZM13.7724 5.43932C13.9872 5.65411 14.3354 5.65411 14.5502 5.43932C14.765 5.22454 14.765 4.8763 14.5502 4.66151L13.7724 5.43932ZM17.0901 1.7242C17.3036 1.50812 17.3015 1.15988 17.0854 0.946397C16.8693 0.732909 16.5211 0.735012 16.3076 0.951093L17.0901 1.7242ZM13.3199 3.97513C13.1064 4.19121 13.1085 4.53945 13.3246 4.75294C13.5406 4.96642 13.8889 4.96432 14.1024 4.74824L13.3199 3.97513ZM17.1162 4.42361L14.0091 1.28988L13.228 2.06436L16.335 5.1981L17.1162 4.42361ZM13.548 1.13166L8.16243 1.82805L8.30349 2.91896L13.6891 2.22258L13.548 1.13166ZM7.84413 1.98451L0.927368 8.89836L1.70502 9.67634L8.62178 2.7625L7.84413 1.98451ZM0.921959 11.3103L7.01192 17.4525L7.79305 16.6781L1.70309 10.5358L0.921959 11.3103ZM9.44989 17.4416L16.222 10.4871L15.434 9.71967L8.66181 16.6741L9.44989 17.4416ZM16.3703 10.1953L17.2679 4.90282L16.1833 4.71889L15.2857 10.0114L16.3703 10.1953ZM7.01192 17.4525C7.68472 18.1311 8.78322 18.1262 9.44989 17.4416L8.66181 16.6741C8.42425 16.9181 8.0328 16.9199 7.79305 16.6781L7.01192 17.4525ZM0.927368 8.89836C0.261745 9.5637 0.259324 10.642 0.921959 11.3103L1.70309 10.5358C1.46697 10.2977 1.46783 9.91343 1.70502 9.67634L0.927368 8.89836ZM9.09102 19.7736L17.925 19.8875L17.9392 18.7876L9.1052 18.6737L9.09102 19.7736ZM19.656 18.1787L19.656 7.84125H18.556L18.556 18.1787H19.656ZM19.5491 7.51536L17.4774 4.69883L16.5913 5.35061L18.6629 8.16714L19.5491 7.51536ZM8.50406 18.0648V16.7584H7.40406V18.0648H8.50406ZM17.925 19.8875C18.8774 19.8998 19.656 19.1311 19.656 18.1787L18.556 18.1787C18.556 18.5181 18.2785 18.792 17.9392 18.7876L17.925 19.8875ZM9.1052 18.6737C8.77195 18.6694 8.50406 18.3981 8.50406 18.0648H7.40406C7.40406 19.0001 8.15584 19.7616 9.09102 19.7736L9.1052 18.6737ZM9.36414 5.58552L6.8983 13.3529L7.94674 13.6858L10.4126 5.91836L9.36414 5.58552ZM12.4795 4.14646L13.7724 5.43932L14.5502 4.66151L13.2573 3.36864L12.4795 4.14646ZM16.3076 0.951093L13.3199 3.97513L14.1024 4.74824L17.0901 1.7242L16.3076 0.951093Z" fill="#FA5950"/>
	</svg>
	</div>',
	'title' => 'Promo Codes',
	'link'=> get_site_url().'/wp-admin/edit.php?post_type=shop_coupon&post_status=publish',
	'type' => 'shop_coupon',
	'submenu'=>false
);


$collaborators_menu = array(
	'name'=>'Collaborators',
	'menu_icon' => '<div class="wp-menu-image" aria-hidden="true"><svg width="18" height="20" viewBox="0 0 18 20" fill="none" xmlns="http://www.w3.org/2000/svg">
	<path d="M3.54439 5.83767C2.74112 5.83767 2.08984 5.10499 2.08984 4.20131C2.08984 3.29762 2.74112 2.56494 3.54439 2.56494C4.34766 2.56494 4.99893 3.29762 4.99893 4.20131C4.99893 5.10499 4.34766 5.83767 3.54439 5.83767Z" stroke="url(#paint0_linear_45272_13658)" stroke-linecap="round" stroke-linejoin="round"/>
	<path d="M4.63636 18.1103H2.45455L2.09091 13.6103L1 13.2012V9.51942C1 8.61574 1.65127 7.88306 2.45455 7.88306H4.63636C5.16509 7.88306 5.628 8.20092 5.88255 8.67547" stroke="url(#paint1_linear_45272_13658)" stroke-linecap="round" stroke-linejoin="round"/>
	<path d="M14.4545 5.83767C15.2578 5.83767 15.9091 5.10499 15.9091 4.20131C15.9091 3.29762 15.2578 2.56494 14.4545 2.56494C13.6513 2.56494 13 3.29762 13 4.20131C13 5.10499 13.6513 5.83767 14.4545 5.83767Z" stroke="url(#paint2_linear_45272_13658)" stroke-linecap="round" stroke-linejoin="round"/>
	<path d="M13.3634 18.1103H15.5452L15.9088 13.6103L16.9997 13.2012V9.51942C16.9997 8.61574 16.3485 7.88306 15.5452 7.88306H13.3634C12.8346 7.88306 12.3717 8.20092 12.1172 8.67547" stroke="url(#paint3_linear_45272_13658)" stroke-linecap="round" stroke-linejoin="round"/>
	<path d="M9.00018 6.24674C7.79509 6.24674 6.81836 5.14792 6.81836 3.79219C6.81836 2.43646 7.79509 1.33765 9.00018 1.33765C10.2053 1.33765 11.182 2.43646 11.182 3.79219C11.182 5.14792 10.2053 6.24674 9.00018 6.24674Z" stroke="url(#paint4_linear_45272_13658)" stroke-linecap="round" stroke-linejoin="round"/>
	<path d="M10.8178 19.3377H7.18146L6.81783 14.4286L5.36328 14.0195V9.9286C5.36328 9.02492 6.01455 8.29224 6.81783 8.29224H11.1815C11.9847 8.29224 12.636 9.02492 12.636 9.9286V14.0195L11.1815 14.4286L10.8178 19.3377Z" stroke="url(#paint5_linear_45272_13658)" stroke-linecap="round" stroke-linejoin="round"/>
	<defs>
	<linearGradient id="paint0_linear_45272_13658" x1="2.08984" y1="5.83767" x2="4.66752" y2="5.83767" gradientUnits="userSpaceOnUse">
	<stop stop-color="#F5286E"/>
	<stop offset="1" stop-color="#FC6D43"/>
	</linearGradient>
	<linearGradient id="paint1_linear_45272_13658" x1="1" y1="18.1103" x2="5.32631" y2="18.1103" gradientUnits="userSpaceOnUse">
	<stop stop-color="#F5286E"/>
	<stop offset="1" stop-color="#FC6D43"/>
	</linearGradient>
	<linearGradient id="paint2_linear_45272_13658" x1="13" y1="5.83767" x2="15.5777" y2="5.83767" gradientUnits="userSpaceOnUse">
	<stop stop-color="#F5286E"/>
	<stop offset="1" stop-color="#FC6D43"/>
	</linearGradient>
	<linearGradient id="paint3_linear_45272_13658" x1="12.1172" y1="18.1103" x2="16.4435" y2="18.1103" gradientUnits="userSpaceOnUse">
	<stop stop-color="#F5286E"/>
	<stop offset="1" stop-color="#FC6D43"/>
	</linearGradient>
	<linearGradient id="paint4_linear_45272_13658" x1="6.81836" y1="6.24674" x2="10.6849" y2="6.24674" gradientUnits="userSpaceOnUse">
	<stop stop-color="#F5286E"/>
	<stop offset="1" stop-color="#FC6D43"/>
	</linearGradient>
	<linearGradient id="paint5_linear_45272_13658" x1="5.36328" y1="19.3377" x2="11.8075" y2="19.3377" gradientUnits="userSpaceOnUse">
	<stop stop-color="#F5286E"/>
	<stop offset="1" stop-color="#FC6D43"/>
	</linearGradient>
	</defs>
	</svg>
	</div>',
	'title' =>'Collaborators',
	'link'=>get_site_url().'/wp-admin/users.php?page=manage-sub-users',
	'type' => 'manage-sub-users',
	'submenu' => false
);


$pages_menu = array(
	'name'=>'Pages',
	'menu_icon' => '<div class="wp-menu-image" aria-hidden="true"><svg width="20" height="23" viewBox="0 0 20 23" fill="none" xmlns="http://www.w3.org/2000/svg">
	<path d="M13.4615 6.53845H1V21.7692H13.4615V6.53845Z" stroke="#78818B" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
	<path d="M3.76923 3.76923H16.2308V19" stroke="#78818B" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
	<path d="M7.9231 1H19V14.8462" stroke="#78818B" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
	</svg>
	</div>',
	'title' => 'Pages',
	'link'=>get_site_url().'/wp-admin/edit.php?post_type=page',
	'submenu'=>false
);

$email_menu = array(
	'name'=>'Emails',
	'menu_icon' => '<div class="wp-menu-image" aria-hidden="true"><svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
	<path d="M14.6582 18.1528C12.6011 18.9388 6.32857 20.2232 2.92532 16.3074C-0.371223 12.5146 1.05976 6.77352 3.52874 3.90426C5.75729 1.30886 10.3682 0.109728 14.4105 1.74985C18.4527 3.38998 19.1247 7.18323 18.9829 9.37064C18.841 11.558 18.1686 13.9156 15.97 14.0849C13.7715 14.2542 13.4175 12.2056 13.2761 11.2135M13.2761 11.2135C13.1346 10.2213 13.6661 5.98496 13.6661 5.98496C8.84512 4.5154 7.1437 7.07823 6.61185 8.65021C6.08 10.2222 5.903 12.6826 7.88812 13.742C9.87325 14.8014 12.4957 13.4335 13.2761 11.2135Z" stroke="#78818B" stroke-width="1.2" stroke-miterlimit="10"/>
	</svg>
	</div>',
	'title' => 'Emails',
	'link'=>get_site_url().'/wp-admin/edit.php?post_type=marketing_email',
	'submenu' => false
);

$text_messages_menu = array(
	'name'=>'Text Messages',
	'menu_icon' => '<div class="wp-menu-image" aria-hidden="true"><svg width="20" height="17" viewBox="0 0 20 17" fill="none" xmlns="http://www.w3.org/2000/svg">
	<path d="M1.50317 1.45737L9.99999 9.18182L18.4968 1.45737" stroke="#78818B" stroke-width="1.2" stroke-miterlimit="10"/>
	<path d="M17.3636 1H2.63636C1.73262 1 1 1.73262 1 2.63636V14.0909C1 14.9946 1.73262 15.7273 2.63636 15.7273H17.3636C18.2674 15.7273 19 14.9946 19 14.0909V2.63636C19 1.73262 18.2674 1 17.3636 1Z" stroke="#78818B" stroke-width="1.2" stroke-miterlimit="10" stroke-linecap="square"/>
	</svg>

	</div>',
	'title' => 'Text Messages',
	'link'=>get_site_url().'/wp-admin/edit.php?post_type=text_message',
	'submenu' => false
);

$media_library_menu = array(
	'name'=>'Media Library',
	'menu_icon' => '<div class="wp-menu-image" aria-hidden="true"><svg width="20" height="18" viewBox="0 0 20 18" fill="none" xmlns="http://www.w3.org/2000/svg">
	<path d="M12.4655 9.58069C12.769 9.77783 12.769 10.2222 12.4655 10.4193L8.5501 12.9624C8.21747 13.1785 7.77775 12.9398 7.77775 12.5431L7.77775 7.45687C7.77775 7.06023 8.21747 6.8215 8.5501 7.03756L12.4655 9.58069Z" fill="#78818B"/>
	<path d="M9.4 4.6L7 1H1V14.8C1 15.2774 1.18964 15.7352 1.52721 16.0728C1.86477 16.4104 2.32261 16.6 2.8 16.6H17.2C17.6774 16.6 18.1352 16.4104 18.4728 16.0728C18.8104 15.7352 19 15.2774 19 14.8V4.6H9.4Z" stroke="#78818B" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
	</svg>
	</div>',
	'title' => 'Media Library',
	'link'=>get_site_url().'/wp-admin/upload.php',                                            
	'submenu' => false
);

$marketing_blogs_menu = array(
	'name'=>'Marketing Blogs',
	'menu_icon' => '<div class="wp-menu-image" aria-hidden="true"><svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
	<path d="M7.54545 16.6221H2.45455C2.06878 16.6221 1.69881 16.4688 1.42603 16.196C1.15325 15.9233 1 15.5533 1 15.1675V2.07662C1 1.69085 1.15325 1.32088 1.42603 1.0481C1.69881 0.775317 2.06878 0.62207 2.45455 0.62207H11.1818C11.5676 0.62207 11.9376 0.775317 12.2103 1.0481C12.4831 1.32088 12.6364 1.69085 12.6364 2.07662V5.71298" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
	<path d="M13.3636 15.1676C14.5686 15.1676 15.5455 14.1908 15.5455 12.9858C15.5455 11.7808 14.5686 10.804 13.3636 10.804C12.1587 10.804 11.1818 11.7808 11.1818 12.9858C11.1818 14.1908 12.1587 15.1676 13.3636 15.1676Z" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
	<path d="M13.3636 10.8039V9.34937" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
	<path d="M14.9061 11.4432L15.9352 10.4141" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
	<path d="M15.5454 12.9858H17" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
	<path d="M14.9061 14.5283L15.9352 15.5574" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
	<path d="M13.3636 15.1675V16.622" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
	<path d="M11.8211 14.5283L10.792 15.5574" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
	<path d="M11.1818 12.9858H9.72726" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
	<path d="M11.8211 11.4432L10.792 10.4141" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
	</svg>
	</div>',
	'link'=>get_site_url().'/wp-admin/edit.php?post_type=marketing-blogs',
	'submenu'=>false
);

$press_posts_menu = array(
	'name'=>'Press Posts',
	'menu_icon' => '<div class="wp-menu-image" aria-hidden="true"><svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
	<path d="M7.54545 16.6221H2.45455C2.06878 16.6221 1.69881 16.4688 1.42603 16.196C1.15325 15.9233 1 15.5533 1 15.1675V2.07662C1 1.69085 1.15325 1.32088 1.42603 1.0481C1.69881 0.775317 2.06878 0.62207 2.45455 0.62207H11.1818C11.5676 0.62207 11.9376 0.775317 12.2103 1.0481C12.4831 1.32088 12.6364 1.69085 12.6364 2.07662V5.71298" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
	<path d="M13.3636 15.1676C14.5686 15.1676 15.5455 14.1908 15.5455 12.9858C15.5455 11.7808 14.5686 10.804 13.3636 10.804C12.1587 10.804 11.1818 11.7808 11.1818 12.9858C11.1818 14.1908 12.1587 15.1676 13.3636 15.1676Z" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
	<path d="M13.3636 10.8039V9.34937" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
	<path d="M14.9061 11.4432L15.9352 10.4141" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
	<path d="M15.5454 12.9858H17" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
	<path d="M14.9061 14.5283L15.9352 15.5574" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
	<path d="M13.3636 15.1675V16.622" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
	<path d="M11.8211 14.5283L10.792 15.5574" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
	<path d="M11.1818 12.9858H9.72726" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
	<path d="M11.8211 11.4432L10.792 10.4141" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
	</svg>
	</div>',
	'link'=>get_site_url().'/wp-admin/edit.php',
	'submenu'=>false
);

$hand_raiser_menu = array(
	'name'=>'Hand Raiser Insights',
	'menu_icon' => '<div class="wp-menu-image" aria-hidden="true"><svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
	<path d="M7.54545 16.6221H2.45455C2.06878 16.6221 1.69881 16.4688 1.42603 16.196C1.15325 15.9233 1 15.5533 1 15.1675V2.07662C1 1.69085 1.15325 1.32088 1.42603 1.0481C1.69881 0.775317 2.06878 0.62207 2.45455 0.62207H11.1818C11.5676 0.62207 11.9376 0.775317 12.2103 1.0481C12.4831 1.32088 12.6364 1.69085 12.6364 2.07662V5.71298" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
	<path d="M13.3636 15.1676C14.5686 15.1676 15.5455 14.1908 15.5455 12.9858C15.5455 11.7808 14.5686 10.804 13.3636 10.804C12.1587 10.804 11.1818 11.7808 11.1818 12.9858C11.1818 14.1908 12.1587 15.1676 13.3636 15.1676Z" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
	<path d="M13.3636 10.8039V9.34937" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
	<path d="M14.9061 11.4432L15.9352 10.4141" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
	<path d="M15.5454 12.9858H17" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
	<path d="M14.9061 14.5283L15.9352 15.5574" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
	<path d="M13.3636 15.1675V16.622" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
	<path d="M11.8211 14.5283L10.792 15.5574" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
	<path d="M11.1818 12.9858H9.72726" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
	<path d="M11.8211 11.4432L10.792 10.4141" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
	</svg>
	</div>',
	'link'=>get_site_url().'/wp-admin/admin.php?page=pipedrive_insights',
	'submenu'=>false
);

$staff_pick_menu = array(
	'name'=>'Staff Pick and Feature',
	'menu_icon' => '<div class="wp-menu-image" aria-hidden="true"><svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
	<path d="M7.54545 16.6221H2.45455C2.06878 16.6221 1.69881 16.4688 1.42603 16.196C1.15325 15.9233 1 15.5533 1 15.1675V2.07662C1 1.69085 1.15325 1.32088 1.42603 1.0481C1.69881 0.775317 2.06878 0.62207 2.45455 0.62207H11.1818C11.5676 0.62207 11.9376 0.775317 12.2103 1.0481C12.4831 1.32088 12.6364 1.69085 12.6364 2.07662V5.71298" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
	<path d="M13.3636 15.1676C14.5686 15.1676 15.5455 14.1908 15.5455 12.9858C15.5455 11.7808 14.5686 10.804 13.3636 10.804C12.1587 10.804 11.1818 11.7808 11.1818 12.9858C11.1818 14.1908 12.1587 15.1676 13.3636 15.1676Z" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
	<path d="M13.3636 10.8039V9.34937" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
	<path d="M14.9061 11.4432L15.9352 10.4141" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
	<path d="M15.5454 12.9858H17" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
	<path d="M14.9061 14.5283L15.9352 15.5574" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
	<path d="M13.3636 15.1675V16.622" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
	<path d="M11.8211 14.5283L10.792 15.5574" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
	<path d="M11.1818 12.9858H9.72726" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
	<path d="M11.8211 11.4432L10.792 10.4141" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
	</svg>
	</div>',
	'link'=>get_site_url().'/wp-admin/admin.php?page=pinned-item-page',
	'submenu'=>false
);


$array_format[] = $dashboard_menu;
$array_format[] = $event_menu;
$array_format[] = $guides_menu;
//$array_format[] = $businesses_menu;
$array_format[] = $promo_codes_menu;
$array_format[] = $collaborators_menu;

if($user_email_ad_hoc_permissions){
	$array_format[] = $email_menu;
}

if($user_message_ad_hoc_permissions){
	$array_format[] = $text_messages_menu;
	
}

if($media_library_ad_hoc_permissions){
	$array_format[] = $media_library_menu;
	
}

if($markeeting_blog_ad_hoc_permissions){
	$array_format[] = $marketing_blogs_menu;
	
}


if($press_posts_ad_hoc_permissions){
	$array_format[] = $press_posts_menu;
	
}

if($all_guides_ad_hoc_permissions){
	$array_format[] = $guides_menu;
	
}

if($publish_pages_ad_hoc_permissions){
	$array_format[] = $pages_menu;
}

if($hand_raiser_ad_hoc_permissions){
	$array_format[] = $hand_raiser_menu;
}

if($staff_pick_ad_hoc_permissions){
	$array_format[] = $staff_pick_menu;
}

// echo '<pre>';
// print_r($array_format);
// echo '</pre>';

$absolute_url = full_url( $_SERVER );
$absolute_url = get_site_url().$absolute_url;

$menu_open = 'wp-menu-open';
if( function_exists('city_partner_user_search_return_index') ) $selected_key = city_partner_user_search_return_index($array_format,$absolute_url);
else $selected_key = null;


?>
<script>
	var html = `<ul id="adminmenu">`;
	<?php foreach($array_format as $k=>$menu_sub){ 
		if(is_int($selected_key) && isset($selected_key) && $selected_key==$k){
			$selected_menu = 'wp-menu-open';
		}else{
			$selected_menu = '';
		}
		if(!empty($menu_sub)){

			$submenu = $menu_sub['submenu'];
			if(!empty($submenu)){
				$wphas = 'wp-has-submenu';
			}else{
				$wphas = '';
			}
			?>
			html += `<li class="<?php echo $wphas;?> wp-not-current-submenu menu-top <?php echo $selected_menu ;?>" id="toplevel_page_wp_pagely">
				<a title="<?php echo $menu_sub['name']?>" href="<?php echo $menu_sub['link']?>" class="wp-has-submenu wp-not-current-submenu menu-top toplevel_page_wp_pagely" aria-haspopup="true">`;


					<?php 
					if(!empty($submenu)){ ?>
						html += `<div class="wp-menu-arrow"><div>`;
						<?php } ?>
					html += `</div></div>
					<?php echo $menu_sub['menu_icon']?>
					<div class="wp-menu-name"><?php echo $menu_sub['name']?></div>
				</a>`;
				<?php 

				if(!empty($submenu)){ ?>
					html += `<ul class="wp-submenu wp-submenu-wrap" style="">`;


						<?php foreach($submenu as $sk=>$sub_val){?>	
							html += `<li <?php echo ($sub_val['link']==$absolute_url?'class="current"':'');?>>`;
								<?php if(!empty($sub_val['link'])){ ?>
									html += `<a href="<?php echo $sub_val['link'];?>" <?php echo (($sub_val['new_tab']==true)?'target="_blank"':''); ?> <?php echo ($sub_val['link']==$absolute_url?'class="current"':'');?> >`;
									<?php } ?>
									html += `<?php echo $sub_val['name'];?> `;

									<?php if(!empty($sub_val['link'])){ ?>
									html += `</a>`;
								<?php } ?>
							html += `</li>`;
						<?php }?>
					html += `</ul>`;
				<?php }?>
			html +=`</li>`
			<?php 
		}
	}?>
	html += `<li class="wp-not-current-submenu logout" id="logout">
		<a href="<?php echo wp_logout_url(); ?>" class="wp-not-current-submenu logout">
			<div class="wp-menu-arrow">
				<div></div></div><div class="wp-menu-image dashicons-before" aria-hidden="true">
					<img src="<?php echo get_site_url();?>/wp-content/plugins/unation-dashboard/admin/assets/top-bar-logo.png" alt="">
				</div>
				<div class="wp-menu-name">Logout</div>
			</a></li>`;
		html += `</ul>`;

		jQuery( document ).ready(function() {
		//jQuery('#adminmenuwrap>ul').remove();
		<?php 
		if($write==true){
			?>
			// document.open();
			// document.write(html);
			// document.close();
			jQuery('div#adminmenuwrap').html(html);
			<?php
		}else{
			?>
			setTimeout(function() {
			jQuery('#adminmenuwrap>ul').html(html);
		}, 500);
	<?php } ?>
	//jQuery('ul#adminmenu > li.wp-has-submenu > a').click(function(e){
	jQuery( "body" ).on( "click", "ul#adminmenu > li.wp-has-submenu > a", function(e) {     
	e.preventDefault();

	jQuery(this).toggleClass('open').next('ul.wp-submenu').slideToggle();
	var class_check = jQuery(this).parent().hasClass( 'wp-menu-open' );

	if(class_check == true){
	jQuery(this).parent().removeClass('wp-menu-open');
	jQuery(this).removeClass('open');
}

});
//jQuery('#wpwrap #adminmenuback').click(function(e){
// jQuery( "body" ).on( "click", '#wpwrap #adminmenuback', function() {    
//     jQuery('#wpwrap').toggleClass('open-menu');
// });

jQuery("#sales_breakdown_wrapper li strong").html(function() {
return jQuery(this)
.html()
.replace("Processing:", "Completed:");
});

});

jQuery(window).on('load',function(){
jQuery('body').addClass('loaded');
});

</script>
<!--<script>
	jQuery( document ).ready(function() {
	<?php if ($absolute_url == get_site_url().'/wp-admin/admin.php?page=my_dashboard&swcfpc=1'){ ?>
		alert(jQuery("ul#adminmenu").closest("#adminmenu").html());
		jQuery("ul#adminmenu").closest("#adminmenu li:nth-child(2)").addClass("wp-menu-open");
		//jQuery('ul#adminmenu li:nth-child(2)').addClass('wp-menu-open');
		//jQuery( "ul#adminmenu li:nth-child(2)").addClass("wp-menu-open");

	<?php } ?>

	});
</script>-->

	<?php if ($absolute_url == get_site_url().'/wp-admin/admin.php?page=my_dashboard&swcfpc=1'){ ?>
		
	<?php } ?>

<?php
}
}

}


add_action("admin_head", "un_city_partner_user_menu");

function city_partner_user_search_return_index($array_format, $search_content)
{
	$match_ind = '';

	foreach ($array_format as $k => $val) {
			$qry_string_arr = explode('&',$_SERVER['QUERY_STRING']);
			if (is_array($qry_string_arr) && count($qry_string_arr) > 0){
				foreach ($qry_string_arr as $key => $value) {
					$qry_string_value_arr = explode('=',$value);
					$qry_string_value[] = $qry_string_value_arr[1];
				}
			}
			if (is_array($qry_string_value) && count($qry_string_value) > 0){
				if (in_array($val['type'], $qry_string_value)){
					$match_ind = $k;
					return $k;
				}
			}
	}

	return $match_ind;
}


if (!function_exists("un_city_partner_capabilities")) {
	function un_city_partner_capabilities()
	{

		$user = wp_get_current_user();

		$to_role = get_role('writer');
		$to_role_cap = $to_role->capabilities;

		$email_ad_hoc_permissions = get_user_meta( $user->ID, 'city_partnr_email_adhoc', true );

		

		un_add_user_role('writer', 'pages', false);
		un_add_user_role('writer', 'marketing_emails', false);
		un_add_user_role('writer', 'text_message', false);
		un_add_user_role('writer', 'guides', true);
		un_add_user_role('writer', 'tribe_events', true);
		un_add_user_role('writer', 'posts', true);
		un_add_user_role('writer', 'products', false);
		un_add_user_role('writer', 'shop_orders', true);
		un_add_user_role('writer', 'shop_coupons', false);

		$to_role->add_cap( 'upload_files' );
		$to_role->add_cap( 'delete_tribe_venues' );
		$to_role->add_cap( 'delete_tribe_organizers' );
		$to_role->add_cap( 'assign_cities' );
		$to_role->add_cap( 'create_users' );
		$to_role->add_cap( 'delete_users' );
		$to_role->add_cap( 'edit_users' );
		$to_role->add_cap( 'list_users' );
		$to_role->add_cap( 'remove_users' );
		$to_role->add_cap( 'manage_options' );
		$to_role->add_cap( 'edit_dashboard' );
		$to_role->add_cap( 'read' );
		$to_role->add_cap( 'assign_shop_coupon_terms' );
		$to_role->add_cap( 'assign_shop_order_terms' );
		$to_role->add_cap( 'delete_shop_coupon_terms' );
		$to_role->add_cap( 'edit_shop_coupon_terms' );
		$to_role->add_cap( 'edit_shop_order_terms' );
		$to_role->add_cap( 'manage_shop_coupon_terms' );
		$to_role->add_cap( 'view_admin_dashboard' );
		
	}
}

add_action('init', 'un_city_partner_capabilities', 9999);

?>

