<?php
include_once( plugin_dir_path( __DIR__ ) . 'unation-permissions.php' );

if (!function_exists("un_business_role_menu")) {
	function un_business_role_menu()
	{

		$user = wp_get_current_user();
		$verified_user_id = get_current_user_id();
		$all_meta_for_user = get_user_meta( $verified_user_id );
        $state= $all_meta_for_user['state'][0];
        $state_result = strtolower($state);

        $city = $all_meta_for_user['un_user_city'][0];
        $city_result = str_replace(' ', '-', strtolower($city));

        if(!empty($state)){
        	$link = get_site_url().'/'.$state_result.'/'.$city_result;
        } else {
        	$link = get_site_url().'/fl/tampa-bay/';
        }

		if (current_user_can('business_role')) {

			$coming_soon = get_site_url() . '/coming-soon';

			$create[] = array(
				'name' => 'UNATION Event',
				'link' => get_site_url() . '/wp-admin/edit.php?post_type=aws-event&page=test-page',
			);
			$create[] = array(
				'name' => 'Offer',
				'link' => get_site_url() . '/wp-admin/edit.php?post_type=unation-deal&page=add-new',
			);
			$create[] = array(
				'name' => 'Business',
				'link' => get_site_url() . '/wp-admin/edit.php?post_type=unation-business&page=add-new',
			);
			$create[] = array(
				'name' => 'Promo code',
				'link' => get_site_url() . '/wp-admin/post-new.php?post_type=shop_coupon',
			);

			$manage[] = array(
				'name' => 'UNATION Event',
				'link' => get_site_url() . '/wp-admin/edit.php?post_type=aws-event&page=all-events',
			);
			$manage[] = array(
				'name' => 'Offers',
				'link' => get_site_url() . '/wp-admin/edit.php?post_type=unation-deal',
			);
			$manage[] = array(
				'name' => 'Businesses',
				'link' => get_site_url() . '/wp-admin/edit.php?post_type=unation-business',
			);
			$manage[] = array(
				'name' => 'Promo code',
				'link' => get_site_url() . '/wp-admin/edit.php?post_type=shop_coupon&post_status=publish',
			);

			$settings[] = array(
				'name' => 'Account Info',
				'link' => get_site_url() . '/wp-admin/admin.php?page=my_profile',
			);
			$settings[] = array(
				'name' => 'Stripe Connect',
				'link' => get_site_url() . '/wp-admin/admin.php?page=stripe_connect',
			);
			$settings[] = array(
				'name' => 'Billing Address',
				'link' => get_site_url() . '/my-account/edit-address/billing',
			);
			$settings[] = array(
				'name' => 'Edit Interests',
				'link' => get_site_url() . '/wp-admin/admin.php?page=edit_interests',
			);
			$settings[] = array(
				'name' => 'Wallet',
				'link' => get_site_url() . '/coming-soon',
			);
			$settings[] = array(
				'name' => 'Purchase History',
				'link' => get_site_url() . '/wp-admin/admin.php?page=purchase_history',
			);
			$settings[] = array(
				'name' => 'Security',
				'link' => get_site_url() . '/wp-admin/admin.php?page=reset_pass',
			);

			$support[] = array(
				'name' => 'Help articles',
				'link' => get_site_url() . '/wp-admin/admin.php?page=help_articles',
			);
			$support[] = array(
				'name' => 'Feedback',
				'link' => get_site_url() . '/wp-admin/admin.php?page=feedback',
			);
			$support[] = array(
				'name' => 'Privacy Policy',
				'link' => get_site_url() . '/privacy',
			);
			$support[] = array(
				'name' => 'FAQs',
				'link' => get_site_url() . '/faqs',
			);

			$collaborators[] = array(
				'name' => 'Event Collaborators',
				'link' => get_site_url() . '/wp-admin/users.php?page=manage-sub-users',
			);

			$array_format = array(
				/*0 => array(
				
				'name'=>'Discover',
				'menu_icon' =>'<div class="wp-menu-image" aria-hidden="true"><svg width="19" height="18" viewBox="0 0 19 18" fill="none" xmlns="http://www.w3.org/2000/svg">
				<path d="M5.57931 13.0394C5.65139 13.0394 5.72321 13.0257 5.79047 12.9992L10.7596 11.0419C10.9083 10.9835 11.0259 10.8659 11.0844 10.7171L13.0416 5.74803C13.1228 5.54196 13.0789 5.30774 12.9286 5.14535C12.7785 4.98296 12.5483 4.92079 12.3366 4.98591L7.03526 6.61067C6.85223 6.66668 6.70913 6.80977 6.65286 6.9928L5.02809 12.2941C4.97476 12.4691 5.00719 12.6589 5.11598 12.8057C5.22451 12.9526 5.39655 13.0394 5.57931 13.0394L5.57931 13.0394ZM7.66549 7.6228L11.5313 6.43805L10.1041 10.0613L6.4808 11.4889L7.66549 7.6228Z" fill="url(#paint0_linear_45694_7419)"/>
				<path d="M9.04199 18C11.4289 18 13.7182 17.0519 15.4062 15.3642C17.0939 13.6762 18.0423 11.3871 18.0423 9C18.0423 6.61314 17.0942 4.32383 15.4062 2.63609C13.7184 0.948144 11.4291 0 9.04227 0C6.65541 0 4.3661 0.948076 2.67808 2.63609C0.990343 4.32383 0.0419922 6.61314 0.0419922 9C0.0446719 11.386 0.993842 13.6738 2.68103 15.361C4.36822 17.0484 6.65589 17.9973 9.04199 18V18ZM9.04199 1.1521V1.15237C11.1234 1.1521 13.1195 1.97881 14.5913 3.45052C16.063 4.92224 16.8897 6.91841 16.8897 8.99979C16.8897 11.0809 16.063 13.0771 14.5913 14.5488C13.1195 16.0205 11.1236 16.8472 9.04227 16.8475C6.96089 16.8475 4.96472 16.0205 3.49328 14.5488C2.02156 13.0771 1.19457 11.0812 1.19457 8.99979C1.19698 6.91923 2.02451 4.92443 3.49568 3.4532C4.96684 1.98203 6.96144 1.15449 9.04199 1.15209V1.1521Z" fill="url(#paint1_linear_45694_7419)"/>
				<defs>
				<linearGradient id="paint0_linear_45694_7419" x1="5.00293" y1="13.0394" x2="12.1614" y2="13.0394" gradientUnits="userSpaceOnUse">
				<stop stop-color="#F5286E"/>
				<stop offset="1" stop-color="#FC6D43"/>
				</linearGradient>
				<linearGradient id="paint1_linear_45694_7419" x1="0.0419922" y1="18" x2="15.9916" y2="18" gradientUnits="userSpaceOnUse">
				<stop stop-color="#F5286E"/>
				<stop offset="1" stop-color="#FC6D43"/>
				</linearGradient>
				</defs>
				</svg>
				</div>',
				'title' => 'Discover',
				'link'=> $link,
				'submenu' => false

			)*/

			);

			$dashboard_menu = array(
				'name' => 'Dashboard',
				'menu_icon' => '<div class="wp-menu-image" aria-hidden="true"><svg width="20" height="16" viewBox="0 0 20 16" fill="none" xmlns="http://www.w3.org/2000/svg">
				<path d="M10.041 1V3.04545" stroke="url(#paint0_linear_45682_7422)" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
				<path d="M19.0415 10H16.9961" stroke="url(#paint1_linear_45682_7422)" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
				<path d="M1.04102 10H3.08647" stroke="url(#paint2_linear_45682_7422)" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
				<path d="M16.4051 3.63611L14.959 5.08224" stroke="url(#paint3_linear_45682_7422)" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
				<path d="M3.67773 3.63623L5.12387 5.08237" stroke="url(#paint4_linear_45682_7422)" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
				<path d="M9.49091 8.45852L7.99609 4.27271" stroke="url(#paint5_linear_45682_7422)" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
				<path d="M17.5826 14.9091C18.5039 13.4969 19.041 11.8119 19.041 10C19.041 5.02955 15.0115 1 10.041 1C5.07056 1 1.04102 5.02955 1.04102 10C1.04102 11.8119 1.57815 13.4969 2.49942 14.9091H17.5826Z" stroke="url(#paint6_linear_45682_7422)" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
				<path d="M10.0407 11.6363C10.9444 11.6363 11.677 10.9036 11.677 9.99989C11.677 9.09615 10.9444 8.36353 10.0407 8.36353C9.13692 8.36353 8.4043 9.09615 8.4043 9.99989C8.4043 10.9036 9.13692 11.6363 10.0407 11.6363Z" stroke="url(#paint7_linear_45682_7422)" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
				<defs>
				<linearGradient id="paint0_linear_45682_7422" x1="10.541" y1="1" x2="10.541" y2="3.04545" gradientUnits="userSpaceOnUse">
				<stop stop-color="#F5286E"/>
				<stop offset="0.645833" stop-color="#FA5950"/>
				<stop offset="1" stop-color="#FC6D43"/>
				</linearGradient>
				<linearGradient id="paint1_linear_45682_7422" x1="18.0188" y1="10" x2="18.0188" y2="11" gradientUnits="userSpaceOnUse">
				<stop stop-color="#F5286E"/>
				<stop offset="0.645833" stop-color="#FA5950"/>
				<stop offset="1" stop-color="#FC6D43"/>
				</linearGradient>
				<linearGradient id="paint2_linear_45682_7422" x1="2.06374" y1="10" x2="2.06374" y2="11" gradientUnits="userSpaceOnUse">
				<stop stop-color="#F5286E"/>
				<stop offset="0.645833" stop-color="#FA5950"/>
				<stop offset="1" stop-color="#FC6D43"/>
				</linearGradient>
				<linearGradient id="paint3_linear_45682_7422" x1="15.6821" y1="3.63611" x2="15.6821" y2="5.08224" gradientUnits="userSpaceOnUse">
				<stop stop-color="#F5286E"/>
				<stop offset="0.645833" stop-color="#FA5950"/>
				<stop offset="1" stop-color="#FC6D43"/>
				</linearGradient>
				<linearGradient id="paint4_linear_45682_7422" x1="4.4008" y1="3.63623" x2="4.4008" y2="5.08237" gradientUnits="userSpaceOnUse">
				<stop stop-color="#F5286E"/>
				<stop offset="0.645833" stop-color="#FA5950"/>
				<stop offset="1" stop-color="#FC6D43"/>
				</linearGradient>
				<linearGradient id="paint5_linear_45682_7422" x1="8.7435" y1="4.27271" x2="8.7435" y2="8.45852" gradientUnits="userSpaceOnUse">
				<stop stop-color="#F5286E"/>
				<stop offset="0.645833" stop-color="#FA5950"/>
				<stop offset="1" stop-color="#FC6D43"/>
				</linearGradient>
				<linearGradient id="paint6_linear_45682_7422" x1="10.041" y1="1" x2="10.041" y2="14.9091" gradientUnits="userSpaceOnUse">
				<stop stop-color="#F5286E"/>
				<stop offset="0.645833" stop-color="#FA5950"/>
				<stop offset="1" stop-color="#FC6D43"/>
				</linearGradient>
				<linearGradient id="paint7_linear_45682_7422" x1="10.0407" y1="8.36353" x2="10.0407" y2="11.6363" gradientUnits="userSpaceOnUse">
				<stop stop-color="#F5286E"/>
				<stop offset="0.645833" stop-color="#FA5950"/>
				<stop offset="1" stop-color="#FC6D43"/>
				</linearGradient>
				</defs>
				</svg>
				</div>',
				'link' => get_site_url() . '/wp-admin/admin.php?page=my_dashboard',
				'type' => 'my_dashboard',
				'submenu' => false
			);	

			$business_menu = array(
				'name' => 'Business Profiles',
				'menu_icon' => '<div class="wp-menu-image" aria-hidden="true">
				<svg width="14" height="20" viewBox="0 0 14 20" fill="none" xmlns="http://www.w3.org/2000/svg">
				<path d="M0.946289 3.40389L7.0414 0.83252L13.1365 3.40389V18.8321H0.946289V3.40389Z" stroke="#FB5F4C" stroke-width="1.2" stroke-miterlimit="10" stroke-linecap="square"/>
				<path d="M3.99316 6.83276V7.68989" stroke="#FB5F4C" stroke-width="1.2" stroke-miterlimit="10" stroke-linecap="square"/>
				<path d="M7.04199 6.83276V7.68989" stroke="#FB5F4C" stroke-width="1.2" stroke-miterlimit="10" stroke-linecap="square"/>
				<path d="M10.0889 6.83276V7.68989" stroke="#FB5F4C" stroke-width="1.2" stroke-miterlimit="10" stroke-linecap="square"/>
				<path d="M3.99512 11.1177V11.9748" stroke="#FB5F4C" stroke-width="1.2" stroke-miterlimit="10" stroke-linecap="square"/>
				<path d="M7.04199 11.1177V11.9748" stroke="#FB5F4C" stroke-width="1.2" stroke-miterlimit="10" stroke-linecap="square"/>
				<path d="M10.0889 11.1177V11.9748" stroke="#FB5F4C" stroke-width="1.2" stroke-miterlimit="10" stroke-linecap="square"/>
				<path d="M6.12051 18.2325V15.1469H7.96806V18.2325H6.12051Z" fill="#78818B" stroke="#FB5F4C" stroke-width="1.2"/>
				</svg>
				
				</div>',
				'link' => get_site_url() . '/wp-admin/edit.php?post_type=unation-business',
				'type' => 'unation-business',
				'submenu' => false
			);
						

			$event_menu = array(
				'name' => 'Events',
				'menu_icon' => '<div class="wp-menu-image" aria-hidden="true"><svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
				<path d="M1.04199 7.33765H19.042" stroke="url(#paint0_linear_45694_7431)" stroke-width="1.2" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
				<path d="M17.3277 2.62341H2.75628C1.8095 2.62341 1.04199 3.39092 1.04199 4.3377V17.6234C1.04199 18.5702 1.8095 19.3377 2.75628 19.3377H17.3277C18.2745 19.3377 19.042 18.5702 19.042 17.6234V4.3377C19.042 3.39092 18.2745 2.62341 17.3277 2.62341Z" stroke="url(#paint1_linear_45694_7431)" stroke-width="1.2" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
				<path d="M5.32715 4.7662V0.909058" stroke="url(#paint2_linear_45694_7431)" stroke-width="1.2" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
				<path d="M14.7568 4.7662V0.909058" stroke="url(#paint3_linear_45694_7431)" stroke-width="1.2" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
				<defs>
				<linearGradient id="paint0_linear_45694_7431" x1="1.04199" y1="8.33765" x2="16.9914" y2="8.33765" gradientUnits="userSpaceOnUse">
				<stop stop-color="#F5286E"/>
				<stop offset="1" stop-color="#FC6D43"/>
				</linearGradient>
				<linearGradient id="paint1_linear_45694_7431" x1="1.04199" y1="19.3377" x2="16.9914" y2="19.3377" gradientUnits="userSpaceOnUse">
				<stop stop-color="#F5286E"/>
				<stop offset="1" stop-color="#FC6D43"/>
				</linearGradient>
				<linearGradient id="paint2_linear_45694_7431" x1="5.32715" y1="4.7662" x2="6.21322" y2="4.7662" gradientUnits="userSpaceOnUse">
				<stop stop-color="#F5286E"/>
				<stop offset="1" stop-color="#FC6D43"/>
				</linearGradient>
				<linearGradient id="paint3_linear_45694_7431" x1="14.7568" y1="4.7662" x2="15.6429" y2="4.7662" gradientUnits="userSpaceOnUse">
				<stop stop-color="#F5286E"/>
				<stop offset="1" stop-color="#FC6D43"/>
				</linearGradient>
				</defs>
				</div>',
				'link' => get_site_url() . '/wp-admin/edit.php?post_type=aws-event&page=all-events',
				'type' => 'aws-event',
				'submenu' => false
			);			

			$offer_menu = array(
				'name' => 'Offers',
				'menu_icon' => '<div class="wp-menu-image" aria-hidden="true"><svg width="12" height="18" viewBox="0 0 12 18" fill="none" xmlns="http://www.w3.org/2000/svg">
				<path d="M3.94479 0.96361L3.94479 0.963627C3.93774 2.14934 4.89211 3.09106 6.07734 3.09812C7.26263 3.10517 8.22809 2.1749 8.23514 0.989175L8.23579 0.881L10.7318 0.895866L10.634 17.3295L8.13797 17.3146L8.13862 17.2065C8.14567 16.0207 7.19137 15.079 6.00609 15.072C4.82087 15.0649 3.85532 15.9952 3.84828 17.1809L3.84763 17.2891L1.3516 17.2742L1.44941 0.840612L3.94544 0.855463L3.94479 0.96361ZM1.58976 16.5593L1.58678 17.0593L2.08678 17.0623L3.1857 17.0688L3.58589 17.0712L3.67587 16.6813C3.91655 15.6383 4.87317 14.8489 6.00735 14.8557C7.14025 14.8624 8.08201 15.6618 8.31052 16.7088L8.39585 17.0998L8.79605 17.1022L9.9014 17.1088L10.4014 17.1118L10.4044 16.6118L10.4635 6.6787L10.4665 6.17871L9.96649 6.17573L2.15185 6.12919L1.65186 6.12621L1.64888 6.6262L1.58976 16.5593ZM1.65612 5.40991L1.65314 5.9099L2.15313 5.91288L9.96777 5.9594L10.4678 5.96237L10.4707 5.46238L10.4937 1.61078L10.4966 1.11079L9.99665 1.10782L8.89129 1.10123L8.4911 1.09885L8.40112 1.4888C8.16014 2.53309 7.20893 3.32118 6.07606 3.31442H6.07605C4.94185 3.30768 3.9947 2.50696 3.76647 1.46121L3.68113 1.07022L3.28095 1.06784L2.18201 1.06129L1.68202 1.05831L1.67904 1.55831L1.65612 5.40991Z" stroke="url(#paint0_linear_45836_6890)"/>
				<defs>
				<linearGradient id="paint0_linear_45836_6890" x1="0.848633" y1="17.8325" x2="10.0516" y2="17.8325" gradientUnits="userSpaceOnUse">
				<stop stop-color="#F5286E"/>
				<stop offset="1" stop-color="#FC6D43"/>
				</linearGradient>
				</defs>
				</svg>
				</div>',
				'link' => get_site_url() . '/wp-admin/edit.php?post_type=unation-deal',
				'type' => 'unation-deal',
				'submenu' => false
			);

			$promocode_menu = array(
				'name' => 'Promo Codes',
				'menu_icon' => '<div class="wp-menu-image" aria-hidden="true"><svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
				<circle cx="11.51" cy="9.21064" r="1.33848" stroke="#FA5950" stroke-width="0.8"/>
				<circle cx="5.71504" cy="9.21064" r="1.33848" stroke="#FA5950" stroke-width="0.8"/>
				<path d="M16.7256 4.81085L17.2679 4.90282L17.3151 4.62425L17.1162 4.42361L16.7256 4.81085ZM13.6185 1.67712L14.0091 1.28988L13.8177 1.09679L13.548 1.13166L13.6185 1.67712ZM8.23296 2.37351L8.16243 1.82805L7.97663 1.85207L7.84413 1.98451L8.23296 2.37351ZM1.31619 9.28735L0.927368 8.89836H0.927368L1.31619 9.28735ZM1.31253 10.9231L1.70309 10.5358H1.70309L1.31253 10.9231ZM7.40249 17.0653L7.79305 16.6781L7.40249 17.0653ZM9.05585 17.0579L8.66181 16.6741H8.66181L9.05585 17.0579ZM15.828 10.1034L16.222 10.4871L16.3416 10.3643L16.3703 10.1953L15.828 10.1034ZM9.09811 19.2237L9.09102 19.7736L9.09811 19.2237ZM17.9321 19.3375L17.925 19.8875L17.9321 19.3375ZM19.106 18.1787H19.656H19.106ZM19.106 7.84125H19.656V7.66076L19.5491 7.51536L19.106 7.84125ZM7.95406 18.0648H7.40406H7.95406ZM10.4126 5.91836C10.5045 5.62884 10.3443 5.31963 10.0548 5.22772C9.76526 5.13581 9.45605 5.296 9.36414 5.58552L10.4126 5.91836ZM6.8983 13.3529C6.80639 13.6424 6.96658 13.9516 7.2561 14.0436C7.54562 14.1355 7.85483 13.9753 7.94674 13.6858L6.8983 13.3529ZM13.2573 3.36864C13.0426 3.15385 12.6943 3.15385 12.4795 3.36864C12.2647 3.58343 12.2647 3.93167 12.4795 4.14646L13.2573 3.36864ZM13.7724 5.43932C13.9872 5.65411 14.3354 5.65411 14.5502 5.43932C14.765 5.22454 14.765 4.8763 14.5502 4.66151L13.7724 5.43932ZM17.0901 1.7242C17.3036 1.50812 17.3015 1.15988 17.0854 0.946397C16.8693 0.732909 16.5211 0.735012 16.3076 0.951093L17.0901 1.7242ZM13.3199 3.97513C13.1064 4.19121 13.1085 4.53945 13.3246 4.75294C13.5406 4.96642 13.8889 4.96432 14.1024 4.74824L13.3199 3.97513ZM17.1162 4.42361L14.0091 1.28988L13.228 2.06436L16.335 5.1981L17.1162 4.42361ZM13.548 1.13166L8.16243 1.82805L8.30349 2.91896L13.6891 2.22258L13.548 1.13166ZM7.84413 1.98451L0.927368 8.89836L1.70502 9.67634L8.62178 2.7625L7.84413 1.98451ZM0.921959 11.3103L7.01192 17.4525L7.79305 16.6781L1.70309 10.5358L0.921959 11.3103ZM9.44989 17.4416L16.222 10.4871L15.434 9.71967L8.66181 16.6741L9.44989 17.4416ZM16.3703 10.1953L17.2679 4.90282L16.1833 4.71889L15.2857 10.0114L16.3703 10.1953ZM7.01192 17.4525C7.68472 18.1311 8.78322 18.1262 9.44989 17.4416L8.66181 16.6741C8.42425 16.9181 8.0328 16.9199 7.79305 16.6781L7.01192 17.4525ZM0.927368 8.89836C0.261745 9.5637 0.259324 10.642 0.921959 11.3103L1.70309 10.5358C1.46697 10.2977 1.46783 9.91343 1.70502 9.67634L0.927368 8.89836ZM9.09102 19.7736L17.925 19.8875L17.9392 18.7876L9.1052 18.6737L9.09102 19.7736ZM19.656 18.1787L19.656 7.84125H18.556L18.556 18.1787H19.656ZM19.5491 7.51536L17.4774 4.69883L16.5913 5.35061L18.6629 8.16714L19.5491 7.51536ZM8.50406 18.0648V16.7584H7.40406V18.0648H8.50406ZM17.925 19.8875C18.8774 19.8998 19.656 19.1311 19.656 18.1787L18.556 18.1787C18.556 18.5181 18.2785 18.792 17.9392 18.7876L17.925 19.8875ZM9.1052 18.6737C8.77195 18.6694 8.50406 18.3981 8.50406 18.0648H7.40406C7.40406 19.0001 8.15584 19.7616 9.09102 19.7736L9.1052 18.6737ZM9.36414 5.58552L6.8983 13.3529L7.94674 13.6858L10.4126 5.91836L9.36414 5.58552ZM12.4795 4.14646L13.7724 5.43932L14.5502 4.66151L13.2573 3.36864L12.4795 4.14646ZM16.3076 0.951093L13.3199 3.97513L14.1024 4.74824L17.0901 1.7242L16.3076 0.951093Z" fill="#FA5950"/>
				</svg>
				</div>',
				'link' => get_site_url() . '/wp-admin/edit.php?post_type=shop_coupon&post_status=publish',
				'type' => 'shop_coupon',
				'submenu' => false
			);

			/*$manage_menu = array(
				'name' => 'Manage',
				'menu_icon' => '<div class="wp-menu-image" aria-hidden="true"><svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
				<path d="M7.54545 16.6221H2.45455C2.06878 16.6221 1.69881 16.4688 1.42603 16.196C1.15325 15.9233 1 15.5533 1 15.1675V2.07662C1 1.69085 1.15325 1.32088 1.42603 1.0481C1.69881 0.775317 2.06878 0.62207 2.45455 0.62207H11.1818C11.5676 0.62207 11.9376 0.775317 12.2103 1.0481C12.4831 1.32088 12.6364 1.69085 12.6364 2.07662V5.71298" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
				<path d="M13.3636 15.1676C14.5686 15.1676 15.5455 14.1908 15.5455 12.9858C15.5455 11.7808 14.5686 10.804 13.3636 10.804C12.1587 10.804 11.1818 11.7808 11.1818 12.9858C11.1818 14.1908 12.1587 15.1676 13.3636 15.1676Z" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
				<path d="M13.3636 10.8039V9.34937" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
				<path d="M14.9061 11.4432L15.9352 10.4141" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
				<path d="M15.5454 12.9858H17" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
				<path d="M14.9061 14.5283L15.9352 15.5574" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
				<path d="M13.3636 15.1675V16.622" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
				<path d="M11.8211 14.5283L10.792 15.5574" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
				<path d="M11.1818 12.9858H9.72726" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
				<path d="M11.8211 11.4432L10.792 10.4141" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
				</svg>
				</div>',
				'link' => $coming_soon,
				'submenu' => $manage
			);

			$settings_menu = array(
				'name' => 'Settings',
				'menu_icon' => '<div class="wp-menu-image" aria-hidden="true"><svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
				<path d="M7.54545 16.6221H2.45455C2.06878 16.6221 1.69881 16.4688 1.42603 16.196C1.15325 15.9233 1 15.5533 1 15.1675V2.07662C1 1.69085 1.15325 1.32088 1.42603 1.0481C1.69881 0.775317 2.06878 0.62207 2.45455 0.62207H11.1818C11.5676 0.62207 11.9376 0.775317 12.2103 1.0481C12.4831 1.32088 12.6364 1.69085 12.6364 2.07662V5.71298" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
				<path d="M13.3636 15.1676C14.5686 15.1676 15.5455 14.1908 15.5455 12.9858C15.5455 11.7808 14.5686 10.804 13.3636 10.804C12.1587 10.804 11.1818 11.7808 11.1818 12.9858C11.1818 14.1908 12.1587 15.1676 13.3636 15.1676Z" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
				<path d="M13.3636 10.8039V9.34937" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
				<path d="M14.9061 11.4432L15.9352 10.4141" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
				<path d="M15.5454 12.9858H17" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
				<path d="M14.9061 14.5283L15.9352 15.5574" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
				<path d="M13.3636 15.1675V16.622" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
				<path d="M11.8211 14.5283L10.792 15.5574" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
				<path d="M11.1818 12.9858H9.72726" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
				<path d="M11.8211 11.4432L10.792 10.4141" stroke="#78909C" stroke-linecap="round" stroke-linejoin="round"/>
				</svg>
				</div>',
				'link' => $coming_soon,
				'submenu' => $settings
			);

			$support_menu = array(
				'name' => 'Support',
				'menu_icon' => '<div class="wp-menu-image" aria-hidden="true"><svg width="17" height="17" viewBox="0 0 17 17" fill="none" xmlns="http://www.w3.org/2000/svg">
				<path d="M8.33333 15.6667C12.3834 15.6667 15.6667 12.3834 15.6667 8.33333C15.6667 4.28325 12.3834 1 8.33333 1C4.28325 1 1 4.28325 1 8.33333C1 12.3834 4.28325 15.6667 8.33333 15.6667Z" stroke="#78909C" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
				<path d="M8.33333 12.6667C8.51743 12.6667 8.66667 12.5174 8.66667 12.3333C8.66667 12.1492 8.51743 12 8.33333 12C8.14924 12 8 12.1492 8 12.3333C8 12.5174 8.14924 12.6667 8.33333 12.6667Z" fill="#78909C"/>
				<path d="M8.33333 12.6667C8.51743 12.6667 8.66667 12.5174 8.66667 12.3333C8.66667 12.1492 8.51743 12 8.33333 12C8.14924 12 8 12.1492 8 12.3333C8 12.5174 8.14924 12.6667 8.33333 12.6667Z" stroke="#78909C" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
				<path d="M6.66669 4.3921C8.05269 3.7791 9.84669 3.8521 10.4597 4.8441C11.0727 5.8361 10.649 6.9891 9.59902 7.87744C8.54902 8.76577 8.33335 9.3001 8.33335 10.0001" stroke="#78909C" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
				</svg>
				</div>',
				'link' => $coming_soon,
				'submenu' => $support
			);*/

			$collaborators_menu = array(
				'name' => 'Collaborators',
				'menu_icon' => '<div class="wp-menu-image" aria-hidden="true"><svg width="18" height="20" viewBox="0 0 18 20" fill="none" xmlns="http://www.w3.org/2000/svg">
				<path d="M3.54439 5.83767C2.74112 5.83767 2.08984 5.10499 2.08984 4.20131C2.08984 3.29762 2.74112 2.56494 3.54439 2.56494C4.34766 2.56494 4.99893 3.29762 4.99893 4.20131C4.99893 5.10499 4.34766 5.83767 3.54439 5.83767Z" stroke="url(#paint0_linear_45272_13658)" stroke-linecap="round" stroke-linejoin="round"/>
				<path d="M4.63636 18.1103H2.45455L2.09091 13.6103L1 13.2012V9.51942C1 8.61574 1.65127 7.88306 2.45455 7.88306H4.63636C5.16509 7.88306 5.628 8.20092 5.88255 8.67547" stroke="url(#paint1_linear_45272_13658)" stroke-linecap="round" stroke-linejoin="round"/>
				<path d="M14.4545 5.83767C15.2578 5.83767 15.9091 5.10499 15.9091 4.20131C15.9091 3.29762 15.2578 2.56494 14.4545 2.56494C13.6513 2.56494 13 3.29762 13 4.20131C13 5.10499 13.6513 5.83767 14.4545 5.83767Z" stroke="url(#paint2_linear_45272_13658)" stroke-linecap="round" stroke-linejoin="round"/>
				<path d="M13.3634 18.1103H15.5452L15.9088 13.6103L16.9997 13.2012V9.51942C16.9997 8.61574 16.3485 7.88306 15.5452 7.88306H13.3634C12.8346 7.88306 12.3717 8.20092 12.1172 8.67547" stroke="url(#paint3_linear_45272_13658)" stroke-linecap="round" stroke-linejoin="round"/>
				<path d="M9.00018 6.24674C7.79509 6.24674 6.81836 5.14792 6.81836 3.79219C6.81836 2.43646 7.79509 1.33765 9.00018 1.33765C10.2053 1.33765 11.182 2.43646 11.182 3.79219C11.182 5.14792 10.2053 6.24674 9.00018 6.24674Z" stroke="url(#paint4_linear_45272_13658)" stroke-linecap="round" stroke-linejoin="round"/>
				<path d="M10.8178 19.3377H7.18146L6.81783 14.4286L5.36328 14.0195V9.9286C5.36328 9.02492 6.01455 8.29224 6.81783 8.29224H11.1815C11.9847 8.29224 12.636 9.02492 12.636 9.9286V14.0195L11.1815 14.4286L10.8178 19.3377Z" stroke="url(#paint5_linear_45272_13658)" stroke-linecap="round" stroke-linejoin="round"/>
				<defs>
				<linearGradient id="paint0_linear_45272_13658" x1="2.08984" y1="5.83767" x2="4.66752" y2="5.83767" gradientUnits="userSpaceOnUse">
				<stop stop-color="#F5286E"/>
				<stop offset="1" stop-color="#FC6D43"/>
				</linearGradient>
				<linearGradient id="paint1_linear_45272_13658" x1="1" y1="18.1103" x2="5.32631" y2="18.1103" gradientUnits="userSpaceOnUse">
				<stop stop-color="#F5286E"/>
				<stop offset="1" stop-color="#FC6D43"/>
				</linearGradient>
				<linearGradient id="paint2_linear_45272_13658" x1="13" y1="5.83767" x2="15.5777" y2="5.83767" gradientUnits="userSpaceOnUse">
				<stop stop-color="#F5286E"/>
				<stop offset="1" stop-color="#FC6D43"/>
				</linearGradient>
				<linearGradient id="paint3_linear_45272_13658" x1="12.1172" y1="18.1103" x2="16.4435" y2="18.1103" gradientUnits="userSpaceOnUse">
				<stop stop-color="#F5286E"/>
				<stop offset="1" stop-color="#FC6D43"/>
				</linearGradient>
				<linearGradient id="paint4_linear_45272_13658" x1="6.81836" y1="6.24674" x2="10.6849" y2="6.24674" gradientUnits="userSpaceOnUse">
				<stop stop-color="#F5286E"/>
				<stop offset="1" stop-color="#FC6D43"/>
				</linearGradient>
				<linearGradient id="paint5_linear_45272_13658" x1="5.36328" y1="19.3377" x2="11.8075" y2="19.3377" gradientUnits="userSpaceOnUse">
				<stop stop-color="#F5286E"/>
				<stop offset="1" stop-color="#FC6D43"/>
				</linearGradient>
				</defs>
				</svg>
				</div>',
				'link' => get_site_url() . '/wp-admin/users.php?page=manage-sub-users',
				'type' => 'manage-sub-users',
				'submenu' => false
			);

			$profile_menu = array(
				'name' => 'Profile',
				'menu_icon' => '<div class="wp-menu-image" aria-hidden="true">
				<svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
				<mask id="path-1-inside-1_49433_17245" fill="white">
				<path fill-rule="evenodd" clip-rule="evenodd" d="M11.7924 8.97803C10.9655 9.51586 9.99372 9.80232 8.99994 9.80116C7.66918 9.79898 6.39364 9.28195 5.4531 8.36347C4.51256 7.44499 3.98383 6.20006 3.98287 4.90175C3.98264 3.93221 4.27718 2.98438 4.82925 2.17821C5.38131 1.37203 6.16608 0.743731 7.08426 0.372811C8.00244 0.00189103 9.01276 -0.0949811 9.98738 0.094452C10.962 0.283885 11.8571 0.75111 12.5595 1.43701C13.2619 2.12291 13.7399 2.99665 13.9332 3.94769C14.1264 4.89873 14.0261 5.88431 13.6451 6.77974C13.264 7.67517 12.6192 8.4402 11.7924 8.97803ZM10.7235 2.38485C10.2131 2.0531 9.61325 1.87651 8.99994 1.87744C8.17873 1.87899 7.39167 2.19827 6.81143 2.76524C6.2312 3.33221 5.90516 4.10056 5.90484 4.90175C5.90484 5.5001 6.08677 6.08501 6.42761 6.58245C6.76844 7.0799 7.25286 7.46753 7.81958 7.69629C8.38629 7.92506 9.00983 7.98468 9.61128 7.8676C10.2127 7.75053 10.7651 7.46202 11.1984 7.0386C11.6318 6.61517 11.9266 6.07585 12.0457 5.48888C12.1647 4.90192 12.1027 4.29368 11.8673 3.74114C11.6319 3.1886 11.2339 2.7166 10.7235 2.38485ZM14.0235 13.1837C15.5697 13.986 16.8875 15.1503 17.8586 16.5721C17.9891 16.7801 18.0314 17.0295 17.9766 17.2674C17.9218 17.5053 17.7742 17.7131 17.5651 17.8467C17.356 17.9803 17.1018 18.0291 16.8564 17.983C16.6109 17.9368 16.3936 17.7992 16.2503 17.5994C15.4532 16.4391 14.3737 15.4896 13.1085 14.8358C11.8433 14.182 10.4317 13.8442 9 13.8527C7.56828 13.8442 6.15672 14.182 4.8915 14.8358C3.62628 15.4896 2.54683 16.4391 1.74965 17.5994C1.60643 17.7992 1.38907 17.9368 1.14364 17.983C0.898207 18.0291 0.643994 17.9803 0.434875 17.8467C0.225756 17.7131 0.078166 17.5053 0.0233832 17.2674C-0.0313996 17.0295 0.0109305 16.7801 0.141403 16.5721C1.11253 15.1503 2.4303 13.986 3.97646 13.1837C5.52261 12.3814 7.24877 11.9661 9 11.9752C10.7512 11.9661 12.4774 12.3814 14.0235 13.1837Z"/>
				</mask>
				<path fill-rule="evenodd" clip-rule="evenodd" d="M11.7924 8.97803C10.9655 9.51586 9.99372 9.80232 8.99994 9.80116C7.66918 9.79898 6.39364 9.28195 5.4531 8.36347C4.51256 7.44499 3.98383 6.20006 3.98287 4.90175C3.98264 3.93221 4.27718 2.98438 4.82925 2.17821C5.38131 1.37203 6.16608 0.743731 7.08426 0.372811C8.00244 0.00189103 9.01276 -0.0949811 9.98738 0.094452C10.962 0.283885 11.8571 0.75111 12.5595 1.43701C13.2619 2.12291 13.7399 2.99665 13.9332 3.94769C14.1264 4.89873 14.0261 5.88431 13.6451 6.77974C13.264 7.67517 12.6192 8.4402 11.7924 8.97803ZM10.7235 2.38485C10.2131 2.0531 9.61325 1.87651 8.99994 1.87744C8.17873 1.87899 7.39167 2.19827 6.81143 2.76524C6.2312 3.33221 5.90516 4.10056 5.90484 4.90175C5.90484 5.5001 6.08677 6.08501 6.42761 6.58245C6.76844 7.0799 7.25286 7.46753 7.81958 7.69629C8.38629 7.92506 9.00983 7.98468 9.61128 7.8676C10.2127 7.75053 10.7651 7.46202 11.1984 7.0386C11.6318 6.61517 11.9266 6.07585 12.0457 5.48888C12.1647 4.90192 12.1027 4.29368 11.8673 3.74114C11.6319 3.1886 11.2339 2.7166 10.7235 2.38485ZM14.0235 13.1837C15.5697 13.986 16.8875 15.1503 17.8586 16.5721C17.9891 16.7801 18.0314 17.0295 17.9766 17.2674C17.9218 17.5053 17.7742 17.7131 17.5651 17.8467C17.356 17.9803 17.1018 18.0291 16.8564 17.983C16.6109 17.9368 16.3936 17.7992 16.2503 17.5994C15.4532 16.4391 14.3737 15.4896 13.1085 14.8358C11.8433 14.182 10.4317 13.8442 9 13.8527C7.56828 13.8442 6.15672 14.182 4.8915 14.8358C3.62628 15.4896 2.54683 16.4391 1.74965 17.5994C1.60643 17.7992 1.38907 17.9368 1.14364 17.983C0.898207 18.0291 0.643994 17.9803 0.434875 17.8467C0.225756 17.7131 0.078166 17.5053 0.0233832 17.2674C-0.0313996 17.0295 0.0109305 16.7801 0.141403 16.5721C1.11253 15.1503 2.4303 13.986 3.97646 13.1837C5.52261 12.3814 7.24877 11.9661 9 11.9752C10.7512 11.9661 12.4774 12.3814 14.0235 13.1837Z" fill="url(#paint0_linear_49433_17245)"/>
				<path d="M8.99994 9.80116L8.99953 10.0512L8.99965 10.0512L8.99994 9.80116ZM11.7924 8.97803L11.6561 8.76846L11.6561 8.76846L11.7924 8.97803ZM5.4531 8.36347L5.62777 8.18461L5.62777 8.18461L5.4531 8.36347ZM3.98287 4.90175L3.73287 4.90181L3.73287 4.90193L3.98287 4.90175ZM4.82925 2.17821L5.03552 2.31946L5.03552 2.31946L4.82925 2.17821ZM7.08426 0.372811L7.1779 0.604611L7.1779 0.604611L7.08426 0.372811ZM9.98738 0.094452L9.93968 0.33986L9.98738 0.094452ZM12.5595 1.43701L12.3848 1.61587L12.3848 1.61587L12.5595 1.43701ZM13.9332 3.94769L13.6882 3.99747L13.6882 3.99747L13.9332 3.94769ZM13.6451 6.77974L13.8751 6.87764L13.8751 6.87764L13.6451 6.77974ZM8.99994 1.87744L8.99956 1.62744L8.99947 1.62744L8.99994 1.87744ZM6.81143 2.76524L6.63671 2.58643L6.63671 2.58643L6.81143 2.76524ZM5.90484 4.90175L5.65484 4.90165L5.65484 4.90175L5.90484 4.90175ZM6.42761 6.58245L6.63384 6.44115L6.63384 6.44115L6.42761 6.58245ZM7.81958 7.69629L7.726 7.92812L7.726 7.92812L7.81958 7.69629ZM9.61128 7.8676L9.56352 7.62221L9.56351 7.62221L9.61128 7.8676ZM17.8586 16.5721L18.0705 16.4392L18.065 16.4311L17.8586 16.5721ZM14.0235 13.1837L13.9084 13.4056L13.9084 13.4056L14.0235 13.1837ZM17.5651 17.8467L17.4306 17.636L17.4306 17.636L17.5651 17.8467ZM16.8564 17.983L16.8101 18.2287L16.8101 18.2287L16.8564 17.983ZM16.2503 17.5994L16.0443 17.741L16.0471 17.745L16.2503 17.5994ZM13.1085 14.8358L12.9937 15.0579L12.9937 15.0579L13.1085 14.8358ZM9 13.8527L8.99852 14.1027L9.00148 14.1027L9 13.8527ZM4.8915 14.8358L5.00627 15.0579L5.00627 15.0579L4.8915 14.8358ZM1.74965 17.5994L1.9529 17.745L1.95571 17.7409L1.74965 17.5994ZM1.14364 17.983L1.09742 17.7373L1.09742 17.7373L1.14364 17.983ZM0.434875 17.8467L0.569451 17.636L0.569449 17.636L0.434875 17.8467ZM0.0233832 17.2674L-0.220242 17.3235L0.0233832 17.2674ZM0.141403 16.5721L-0.0651949 16.431L-0.0703802 16.4393L0.141403 16.5721ZM3.97646 13.1837L4.09161 13.4056L4.09161 13.4056L3.97646 13.1837ZM9 11.9752L8.9987 12.2253L9.0013 12.2252L9 11.9752ZM8.99965 10.0512C10.0415 10.0524 11.0609 9.75208 11.9287 9.1876L11.6561 8.76846C10.8702 9.27964 9.9459 9.55226 9.00023 9.55116L8.99965 10.0512ZM5.27843 8.54233C6.26621 9.50694 7.60453 10.0489 8.99953 10.0512L9.00035 9.55116C7.73383 9.54909 6.52107 9.05696 5.62777 8.18461L5.27843 8.54233ZM3.73287 4.90193C3.73388 6.26846 4.29045 7.57752 5.27843 8.54233L5.62777 8.18461C4.73467 7.31246 4.23378 6.13166 4.23287 4.90157L3.73287 4.90193ZM4.62298 2.03695C4.04265 2.8844 3.73262 3.88141 3.73287 4.90181L4.23287 4.90169C4.23265 3.983 4.51172 3.08437 5.03552 2.31946L4.62298 2.03695ZM6.99062 0.141011C6.02746 0.530103 5.20325 1.18959 4.62298 2.03695L5.03552 2.31946C5.55938 1.55447 6.30471 0.957359 7.1779 0.604611L6.99062 0.141011ZM10.0351 -0.150955C9.01315 -0.349583 7.95373 -0.248061 6.99062 0.141011L7.1779 0.604611C8.05115 0.251843 9.01236 0.159621 9.93968 0.33986L10.0351 -0.150955ZM12.7342 1.25815C11.9965 0.537739 11.057 0.0476776 10.0351 -0.150955L9.93968 0.33986C10.867 0.520093 11.7178 0.964482 12.3848 1.61587L12.7342 1.25815ZM14.1781 3.89791C13.9748 2.89717 13.4719 1.97862 12.7342 1.25815L12.3848 1.61587C13.0518 2.26719 13.505 3.09614 13.6882 3.99747L14.1781 3.89791ZM13.8751 6.87764C14.2759 5.93577 14.3815 4.8987 14.1781 3.89791L13.6882 3.99747C13.8713 4.89876 13.7763 5.83286 13.415 6.68185L13.8751 6.87764ZM11.9287 9.1876C12.7966 8.62308 13.4743 7.81944 13.8751 6.87764L13.415 6.68185C13.0537 7.53091 12.4419 8.25733 11.6561 8.76846L11.9287 9.1876ZM9.00032 2.12744C9.56552 2.12658 10.1178 2.28935 10.5872 2.59446L10.8597 2.17523C10.3083 1.81684 9.66098 1.62644 8.99956 1.62744L9.00032 2.12744ZM6.98615 2.94405C7.51916 2.42323 8.24344 2.12887 9.00041 2.12744L8.99947 1.62744C8.11401 1.62911 7.26418 1.97332 6.63671 2.58643L6.98615 2.94405ZM6.15484 4.90185C6.15513 4.16888 6.45335 3.46466 6.98615 2.94405L6.63671 2.58643C6.00904 3.19975 5.65518 4.03224 5.65484 4.90165L6.15484 4.90185ZM6.63384 6.44115C6.32128 5.98496 6.15484 5.44925 6.15484 4.90175L5.65484 4.90175C5.65484 5.55096 5.85226 6.18505 6.22137 6.72376L6.63384 6.44115ZM7.91316 7.46447C7.39143 7.25387 6.94646 6.89741 6.63384 6.44115L6.22137 6.72376C6.59042 7.26239 7.1143 7.68119 7.726 7.92812L7.91316 7.46447ZM9.56351 7.62221C9.00937 7.73007 8.43494 7.67509 7.91316 7.46447L7.726 7.92812C8.33765 8.17502 9.01029 8.23928 9.65905 8.113L9.56351 7.62221ZM11.0237 6.85979C10.6257 7.24869 10.1176 7.51435 9.56352 7.62221L9.65905 8.113C10.3078 7.98671 10.9045 7.67535 11.3731 7.21741L11.0237 6.85979ZM11.8007 5.43918C11.6917 5.97644 11.4216 6.47095 11.0237 6.85979L11.3731 7.21741C11.8419 6.75939 12.1615 6.17526 12.2907 5.53858L11.8007 5.43918ZM11.6373 3.83912C11.8529 4.34522 11.9096 4.90197 11.8007 5.43918L12.2907 5.53858C12.4198 4.90186 12.3525 4.24214 12.0973 3.64317L11.6373 3.83912ZM10.5872 2.59446C11.0566 2.89953 11.4217 3.33294 11.6373 3.83912L12.0973 3.64317C11.8422 3.04427 11.4112 2.53366 10.8597 2.17523L10.5872 2.59446ZM18.065 16.4311C17.0703 14.9748 15.721 13.7829 14.1387 12.9618L13.9084 13.4056C15.4184 14.1891 16.7046 15.3258 17.6522 16.7131L18.065 16.4311ZM18.2202 17.3235C18.29 17.0205 18.2359 16.7031 18.0704 16.4393L17.6468 16.7049C17.7422 16.8571 17.7728 17.0385 17.733 17.2113L18.2202 17.3235ZM17.6997 18.0574C17.963 17.8892 18.1505 17.6264 18.2202 17.3235L17.733 17.2113C17.6932 17.3843 17.5855 17.537 17.4306 17.636L17.6997 18.0574ZM16.8101 18.2287C17.1177 18.2865 17.4366 18.2254 17.6997 18.0574L17.4306 17.636C17.2754 17.7351 17.0859 17.7718 16.9026 17.7373L16.8101 18.2287ZM16.0471 17.745C16.2285 17.9981 16.5026 18.1708 16.8101 18.2287L16.9026 17.7373C16.7193 17.7028 16.5586 17.6004 16.4536 17.4537L16.0471 17.745ZM12.9937 15.0579C14.2228 15.693 15.2707 16.615 16.0443 17.7409L16.4564 17.4578C15.6356 16.2631 14.5246 15.2862 13.2233 14.6137L12.9937 15.0579ZM9.00148 14.1027C10.393 14.0944 11.7646 14.4227 12.9937 15.0579L13.2233 14.6137C11.9219 13.9412 10.4704 13.594 8.99852 13.6027L9.00148 14.1027ZM5.00627 15.0579C6.23536 14.4227 7.60701 14.0944 8.99852 14.1027L9.00148 13.6027C7.52955 13.594 6.07807 13.9412 4.77673 14.6137L5.00627 15.0579ZM1.95571 17.7409C2.72927 16.615 3.7772 15.693 5.00627 15.0579L4.77673 14.6137C3.47535 15.2862 2.36438 16.2631 1.5436 17.4578L1.95571 17.7409ZM1.18985 18.2287C1.49744 18.1708 1.77149 17.9981 1.95286 17.745L1.54645 17.4537C1.44137 17.6004 1.2807 17.7028 1.09742 17.7373L1.18985 18.2287ZM0.300299 18.0574C0.563416 18.2254 0.882348 18.2865 1.18985 18.2287L1.09742 17.7373C0.914065 17.7718 0.724572 17.7351 0.569451 17.636L0.300299 18.0574ZM-0.220242 17.3235C-0.150497 17.6264 0.0369922 17.8892 0.300301 18.0574L0.569449 17.636C0.41452 17.537 0.306829 17.3843 0.267009 17.2113L-0.220242 17.3235ZM-0.0703802 16.4393C-0.235913 16.7031 -0.290019 17.0205 -0.220242 17.3235L0.267009 17.2113C0.22722 17.0385 0.257774 16.8571 0.353185 16.7049L-0.0703802 16.4393ZM3.86131 12.9618C2.27896 13.7829 0.929656 14.9748 -0.0650377 16.4311L0.347843 16.7131C1.2954 15.3258 2.58165 14.1891 4.09161 13.4056L3.86131 12.9618ZM9.0013 11.7252C7.20978 11.7159 5.44363 12.1407 3.86131 12.9618L4.09161 13.4056C5.6016 12.622 7.28776 12.2163 8.9987 12.2252L9.0013 11.7252ZM14.1387 12.9618C12.5564 12.1407 10.7902 11.7159 8.9987 11.7252L9.0013 12.2252C10.7122 12.2163 12.3984 12.622 13.9084 13.4056L14.1387 12.9618Z" fill="white" mask="url(#path-1-inside-1_49433_17245)"/>
				<defs>
				<linearGradient id="paint0_linear_49433_17245" x1="0" y1="18" x2="15.9494" y2="18" gradientUnits="userSpaceOnUse">
				<stop stop-color="#F5286E"/>
				<stop offset="1" stop-color="#FC6D43"/>
				</linearGradient>
				</defs>
				</svg>
				</div>',
				'link' => get_site_url() . '/wp-admin/admin.php?page=regular-user-profile-overview',					
				'type' => 'regular-user-profile-overview',
				'submenu' => false
			);


			$array_format[] = $dashboard_menu;
			$array_format[] = $business_menu;			
			$array_format[] = $event_menu;			
			$array_format[] = $offer_menu;
			$array_format[] = $promocode_menu;
			$array_format[] = $collaborators_menu;
			$array_format[] = $profile_menu;
			

			$absolute_url = full_url($_SERVER);
			$absolute_url = get_site_url() . $absolute_url;

			$menu_open = 'wp-menu-open';
			if( function_exists('business_role_user_search_return_index') ) $selected_key = business_role_user_search_return_index($array_format,$absolute_url);
else $selected_key = null;
			

			?>
			<script>
				var html = `<ul id="adminmenu">`;
				<?php foreach ($array_format as $k => $menu_sub) {
					if (is_int($selected_key) && isset($selected_key) && $selected_key == $k) {
						$selected_menu = 'wp-menu-open';
					} else {
						$selected_menu = '';
					}
					if (!empty($menu_sub)) {

						$submenu = $menu_sub['submenu'];
						if (!empty($submenu)) {
							$wphas = 'wp-has-submenu';
						} else {
							$wphas = '';
						}
						?>
						html += `<li class="<?php echo $wphas; ?> wp-not-current-submenu menu-top <?php echo $selected_menu; ?>" id="toplevel_page_wp_pagely">
							<a title="<?php echo $menu_sub['name'] ?>" href="<?php echo $menu_sub['link'] ?>" class="wp-has-submenu wp-not-current-submenu menu-top toplevel_page_wp_pagely" aria-haspopup="true">`;


								<?php
								if (!empty($submenu)) { ?>
									html += `<div class="wp-menu-arrow"><div>`;
									<?php } ?>
								html += `</div></div>
								<?php echo $menu_sub['menu_icon'] ?>
								<div class="wp-menu-name"><?php echo $menu_sub['name'] ?></div>
							</a>`;
							<?php

							if (!empty($submenu)) { ?>
								html += `<ul class="wp-submenu wp-submenu-wrap" style="">`;


									<?php foreach ($submenu as $sk => $sub_val) { ?>
										html += `<li <?php echo ($sub_val['link'] == $absolute_url ? 'class="current"' : ''); ?>>`;
											<?php if (!empty($sub_val['link'])) { ?>
												html += `<a href="<?php echo $sub_val['link']; ?>" <?php echo (($sub_val['new_tab'] == true) ? 'target="_blank"' : ''); ?> <?php echo ($sub_val['link'] == $absolute_url ? 'class="current"' : ''); ?> >`;
												<?php } ?>
												html += `<?php echo $sub_val['name']; ?> `;

												<?php if (!empty($sub_val['link'])) { ?>
												html += `</a>`;
											<?php } ?>
										html += `</li>`;
									<?php } ?>
								html += `</ul>`;
							<?php } ?>
						html += `</li>`
						<?php
					}
				} ?>
				html += `<li class="wp-not-current-submenu logout" id="logout">
					<a href="<?php echo wp_logout_url(); ?>" class="wp-not-current-submenu logout">
						<div class="wp-menu-arrow">
							<div></div></div><div class="wp-menu-image dashicons-before" aria-hidden="true">
								<img src="<?php echo get_site_url(); ?>/wp-content/plugins/unation-dashboard/admin/assets/top-bar-logo.png" alt="">
							</div>
							<div class="wp-menu-name">Logout</div>
						</a></li>`;
					html += `</ul>`;

					jQuery(document).ready(function() {
					//jQuery('#adminmenuwrap>ul').remove();
					<?php
					if ($write == true) {
						?>
						// document.open();
						// document.write(html);
						// document.close();
						jQuery('div#adminmenuwrap').html(html);
						<?php
					} else {
						?>
						setTimeout(function() {
						jQuery('#adminmenuwrap>ul').html(html);
					}, 500);
				<?php } ?>
				//jQuery('ul#adminmenu > li.wp-has-submenu > a').click(function(e){
				jQuery("body").on("click", "ul#adminmenu > li.wp-has-submenu > a", function(e) {
				e.preventDefault();

				jQuery(this).toggleClass('open').next('ul.wp-submenu').slideToggle();
				var class_check = jQuery(this).parent().hasClass('wp-menu-open');

				if (class_check == true) {
				jQuery(this).parent().removeClass('wp-menu-open');
				jQuery(this).removeClass('open');
			}

		});
		//jQuery('#wpwrap #adminmenuback').click(function(e){
		// jQuery( "body" ).on( "click", '#wpwrap #adminmenuback', function() {    
		//     jQuery('#wpwrap').toggleClass('open-menu');
		// });

		jQuery("#sales_breakdown_wrapper li strong").html(function() {
		return jQuery(this)
		.html()
		.replace("Processing:", "Completed:");
	});

});

jQuery(window).on('load', function() {
jQuery('body').addClass('loaded');
});
</script>
<style>
	.woocommerce-embed-page #wpwrap #wpcontent .woocommerce-layout {
    min-height: 0;
}
.profile svg {
	filter: invert(0) !important;
}
</style>
<?php if(strpos($absolute_url, 'admin.php?page=my_dashboard') == true) { ?>
		
	<?php } ?>
<?php
}
}
}


add_action("admin_head", "un_business_role_menu");

function business_role_user_search_return_index($array_format, $search_content)
{
	$match_ind = '';

	foreach ($array_format as $k => $val) {
			$qry_string_arr = explode('&',$_SERVER['QUERY_STRING']);
			if (is_array($qry_string_arr) && count($qry_string_arr) > 0){
				foreach ($qry_string_arr as $key => $value) {
					$qry_string_value_arr = explode('=',$value);
					$qry_string_value[] = $qry_string_value_arr[1];
				}
			}
			if (is_array($qry_string_value) && count($qry_string_value) > 0){
				if (in_array($val['type'], $qry_string_value)){
					$match_ind = $k;
					return $k;
				}
			}
	}
	return $match_ind;
}

if (!function_exists("un_business_role_capabilities")) {
	function un_business_role_capabilities()
	{

		$user = wp_get_current_user();

		if (current_user_can('business_role')) {
		
			$to_role = get_role('business_role');
			$to_role_cap = $to_role->capabilities;

			un_add_user_role('business_role', 'tribe_events', false);
			un_add_user_role('business_role', 'aws-event', false);
			un_add_user_role('business_role', 'unation-deal', false);
			un_add_user_role('business_role', 'unation-business', false);

			$to_role->add_cap( 'edit_posts');
			$to_role->add_cap( 'edit_published_posts');
			$to_role->add_cap( 'edit_private_posts');
			$to_role->add_cap( 'read');
			$to_role->add_cap( 'read_private_shop_orders');
			$to_role->add_cap( 'assign_shop_coupon_terms');
			$to_role->add_cap( 'assign_shop_order_terms');
			$to_role->add_cap( 'delete_shop_coupon_terms');
			$to_role->add_cap( 'edit_shop_coupon_terms');
			$to_role->add_cap( 'edit_shop_order_terms');
			$to_role->add_cap( 'manage_shop_coupon_terms');

			$to_role->add_cap( 'view_admin_dashboard');
			$to_role->add_cap( 'edit_dashboard');

		}
	}
}

add_action('init', 'un_business_role_capabilities', 9999);

